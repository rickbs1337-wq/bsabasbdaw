package pilot.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import pilot.domain.*
import kotlin.math.abs
import kotlin.math.min

data class Detection(val kind: Mark, val area: Area, val confidence: Float)

data class Observation(
    val lobby: Boolean = false, val play: Boolean = false, val hud: Boolean = false,
    val exit: Boolean = false, val result: Result? = null, val world: World? = null,
    val detections: List<Detection> = emptyList()
)

class FrameVision : AutoCloseable {
    private val reader = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val openCv = runCatching { OpenCVLoader.initLocal() }.getOrDefault(false)
    private var previous = emptyList<Actor>()
    private var previousWalls = emptyList<Area>()
    private var previousSelf: Vec? = null
    private var camera = Vec.ZERO

    fun inspect(bitmap: Bitmap, calibration: Calibration, threshold: Float, dt: Float): Observation {
        if (!calibration.comparable(bitmap)) return Observation()
        val templateMinimum = maxOf(.895f, threshold)
        fun match(mark: Mark) = calibration.score(mark, bitmap) >= templateMinimum
        val lobby = match(Mark.LOBBY) && match(Mark.MODE)
        val hud = match(Mark.HUD)
        val exit = match(Mark.EXIT)
        val win = calibration.score(Mark.WIN, bitmap)
        val loss = calibration.score(Mark.LOSS, bitmap)
        val result = if (exit && maxOf(win, loss) >= templateMinimum && abs(win - loss) >= .023f) {
            if (win > loss) Result.WIN else Result.LOSS
        } else null
        val detections = mutableListOf<Detection>()
        for (mark in listOf(Mark.LOBBY, Mark.MODE, Mark.PLAY, Mark.HUD, Mark.WIN, Mark.LOSS, Mark.EXIT, Mark.SUPER)) {
            val reference = calibration.marks[mark] ?: continue
            val score = calibration.score(mark, bitmap)
            if (score >= templateMinimum) detections += Detection(mark, reference.area, score)
        }
        val world = if (hud && !lobby && !exit) detect(bitmap, calibration, match(Mark.SUPER), dt, detections) else {
            previous = emptyList()
            previousWalls = emptyList()
            previousSelf = null
            camera = Vec.ZERO
            null
        }
        return Observation(lobby, lobby && match(Mark.PLAY), hud, exit, result, world, detections)
    }

    suspend fun trophies(frame: Bitmap, reference: Reference): Int? {
        val rect = reference.area
        val x = (rect.left * frame.width).toInt().coerceIn(0, frame.width - 1)
        val y = (rect.top * frame.height).toInt().coerceIn(0, frame.height - 1)
        val width = ((rect.right - rect.left) * frame.width).toInt().coerceIn(1, frame.width - x)
        val height = ((rect.bottom - rect.top) * frame.height).toInt().coerceIn(1, frame.height - y)
        if (height < 3 || width < 4) return null
        val crop = Bitmap.createBitmap(frame, x, y, width, height)
        val factor = min(6, maxOf(1, 68 / height))
        val enlarged = Bitmap.createScaledBitmap(crop, width * factor, height * factor, true)
        return try {
            val text = reader.process(InputImage.fromBitmap(enlarged, 0)).await().text.trim()
            when {
                text.matches(Regex("[0-9]{1,6}")) -> text.toIntOrNull()
                text.matches(Regex("[0-9]{1,3}[ ,.]([0-9]{3})")) -> text.filter(Char::isDigit).toIntOrNull()
                else -> null
            }
        } finally {
            if (enlarged !== crop) enlarged.recycle()
            if (crop !== frame) crop.recycle()
        }
    }

    private fun detect(bitmap: Bitmap, calibration: Calibration, superReady: Boolean, dt: Float,
        detections: MutableList<Detection>): World? {
        if (!openCv) return null
        val rgba = Mat()
        val rgb = Mat()
        return try {
            Utils.bitmapToMat(bitmap, rgba)
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
            fun detect(mark: Mark, actor: Boolean) = calibration.marks[mark]?.values?.firstOrNull()?.let {
                regions(rgb, it, actor).also { found ->
                    found.forEach { (area, confidence) -> detections += Detection(mark, area, confidence) }
                }
            }.orEmpty()
            val selfCandidates = detect(Mark.SELF, true)
            val probe = previousSelf ?: calibration.marks[Mark.SELF]?.area?.center?.plus(Vec(0f, .025f))
            val near = probe?.let { anchor ->
                val ranked = selfCandidates.sortedBy { it.first.center.distance(anchor) }
                ranked.firstOrNull()?.takeIf { candidate ->
                    val distance = candidate.first.center.distance(anchor)
                    val runnerUp = ranked.getOrNull(1)?.first?.center?.distance(anchor)
                    distance < .22f && (runnerUp == null || runnerUp - distance > .10f)
                }
            }
            val self = (selfCandidates.singleOrNull() ?: near)?.let { (area, confidence) ->
                val full = calibration.marks[Mark.SELF]?.area?.let { it.right - it.left }
                Actor(area.center, confidence, full?.takeIf { it > .012f }
                    ?.let { ((area.right - area.left) / it).coerceIn(0f, 1f) })
            }
            previousSelf = self?.point ?: previousSelf
            val enemies = detect(Mark.ENEMY, true).map { (area, confidence) ->
                val p = area.center
                val known = previous.minByOrNull { it.point.distance(p) }?.takeIf { it.point.distance(p) < .095f }
                Actor(p, confidence, if (area.right - area.left > .06f) .9f else null,
                    known?.let { (p - it.point) * (1f / dt.coerceAtLeast(.1f)) } ?: Vec.ZERO)
            }
            previous = enemies
            val walls = detect(Mark.WALL, false).map { it.first }
            val deltas = walls.mapNotNull { wall ->
                previousWalls.filter { abs((it.right - it.left) - (wall.right - wall.left)) < .022f &&
                    abs((it.bottom - it.top) - (wall.bottom - wall.top)) < .022f }
                    .minByOrNull { wall.center.distance(it.center) }?.let { wall.center - it.center }
                    ?.takeIf { it.length() < .16f }
            }
            if (deltas.size >= 2) {
                val common = deltas.minBy { candidate -> deltas.sumOf { it.distance(candidate).toDouble() } }
                if (deltas.count { it.distance(common) < .032f } > deltas.size / 2) camera -= common
            }
            previousWalls = walls
            World(self, enemies, detect(Mark.ALLY, true).map { Actor(it.first.center, it.second) },
                walls, detect(Mark.HAZARD, false).map { it.first }, superReady = superReady,
                confidence = self?.confidence ?: 0f, cameraOffset = camera)
        } finally {
            rgba.release()
            rgb.release()
        }
    }

    private fun regions(rgb: Mat, color: Int, actor: Boolean): List<Pair<Area, Float>> {
        val mask = Mat()
        val labels = Mat()
        val stats = Mat()
        val centers = Mat()
        try {
            val tolerance = if (actor) 34 else 21
            val red = Color.red(color)
            val green = Color.green(color)
            val blue = Color.blue(color)
            fun bounds(sign: Int) = Scalar((red + sign * tolerance).coerceIn(0,255).toDouble(),
                (green + sign * tolerance).coerceIn(0,255).toDouble(),
                (blue + sign * tolerance).coerceIn(0,255).toDouble())
            Core.inRange(rgb, bounds(-1), bounds(1), mask)
            if (!actor) {
                val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, org.opencv.core.Size(3.0, 3.0))
                try { Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel) }
                finally { kernel.release() }
            }
            val labelsCount = Imgproc.connectedComponentsWithStats(mask, labels, stats, centers, 8, CvType.CV_32S)
            val width = rgb.cols().toFloat()
            val height = rgb.rows().toFloat()
            val entries = mutableListOf<Pair<Area, Float>>()
            val row = IntArray(5)
            for (i in 1 until labelsCount) {
                stats.get(i, 0, row)
                val (left, top, w, h, pixels) = row
                val fill = pixels.toFloat() / (w * h)
                if (actor && (w / width !in .009f.. .105f || h / height !in .002f.. .031f ||
                        w < h * 2 || fill < .55 || top / height !in .10f.. .88f)) continue
                if (!actor && (pixels < 100 || w / width < .022f || h / height < .024f ||
                        fill < .28f || w / width > .85f && h / height > .85f)) continue
                val topNormalized = (top / height + if (actor) .025f else 0f).coerceAtMost(1f)
                entries += Area(left / width, topNormalized, (left + w) / width,
                    (topNormalized + h / height).coerceAtMost(1f)) to (.61f + .37f * fill)
            }
            return entries.sortedByDescending { it.second }.take(if (actor) 16 else 32)
        } finally {
            mask.release()
            labels.release()
            stats.release()
            centers.release()
        }
    }

    override fun close() = reader.close()
}
