package pilot.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import pilot.domain.Area
import kotlin.math.abs

enum class Sample { TEMPLATE, LOCATION, COLOR }

enum class Mark(val title: String, val hint: String, val sample: Sample, val required: Boolean = true) {
    LOBBY("Выбранный боец", "Выдели имя или постоянный значок бойца в лобби.", Sample.TEMPLATE),
    MODE("Режим", "Выдели название Столкновения в лобби.", Sample.TEMPLATE),
    TROPHIES("Цифры кубков", "Обведи только число кубков выбранного бойца в лобби.", Sample.LOCATION),
    PLAY("Играть", "Выдели постоянную часть кнопки запуска в лобби.", Sample.TEMPLATE),
    HUD("Признак боя", "Выдели неизменную иконку интерфейса, видимую только в бою.", Sample.TEMPLATE),
    MOVE("Джойстик движения", "Выдели всю неподвижную окружность джойстика движения.", Sample.LOCATION),
    ATTACK("Джойстик атаки", "Выдели окружность джойстика обычной атаки.", Sample.LOCATION),
    SELF("Цвет полоски бойца", "Выдели цветную часть полной полоски здоровья бойца от края до края.", Sample.COLOR),
    ENEMY("Цвет полоски врага", "Выдели однотонный участок полоски здоровья врага.", Sample.COLOR),
    WALL("Цвет стены", "Выдели однотонный участок непрозрачного препятствия.", Sample.COLOR, false),
    HAZARD("Цвет опасной зоны", "Возьми однотонный участок зоны, в которую нельзя идти.", Sample.COLOR, false),
    ALLY("Цвет полоски союзника", "Возьми однотонный участок полоски союзника.", Sample.COLOR, false),
    SUPER("Готовый супер", "Выдели кнопку с готовым супером. Цвет кнопки до зарядки должен отличаться.", Sample.TEMPLATE, false),
    WIN("Экран победы", "Выдели постоянное слово победного результата.", Sample.TEMPLATE),
    LOSS("Экран поражения", "Выдели постоянное слово проигрышного результата.", Sample.TEMPLATE),
    EXIT("Выход из результатов", "Выдели постоянную часть кнопки возврата в лобби.", Sample.TEMPLATE)
}

data class Reference(val area: Area, val values: List<Int>)
data class Calibration(
    val fighter: String = "",
    val aspect: Float = 0f,
    val marks: Map<Mark, Reference> = emptyMap()
) {
    val missing get() = Mark.entries.filter { it.required && it !in marks }
    fun comparable(frame: Bitmap) = aspect > 0f && abs((frame.width.toFloat() / frame.height) / aspect - 1) < .022f

    fun add(fighter: String, mark: Mark, frame: Bitmap, area: Area): Calibration {
        require(frame.width > frame.height) { "Нужен горизонтальный кадр игры" }
        require(this.fighter.isEmpty() || this.fighter == fighter) { "Сначала сбрось калибровку другого бойца" }
        require(aspect == 0f || comparable(frame)) { "Размер кадра изменился. Проверь ориентацию и настройки экрана" }
        require(area.right - area.left >= .006f && area.bottom - area.top >= .006f) { "Выдели область чуть больше" }
        val values = when (mark.sample) {
            Sample.TEMPLATE -> signature(frame, area)
            Sample.COLOR -> listOf(sampleColor(frame, area))
            Sample.LOCATION -> emptyList()
        }
        return Calibration(fighter, frame.width.toFloat() / frame.height, marks + (mark to Reference(area, values)))
    }
}

private const val SignatureWidth = 16
private const val SignatureHeight = 10

private fun signature(bitmap: Bitmap, area: Area): List<Int> =
    (0 until SignatureHeight).flatMap { y ->
        (0 until SignatureWidth).map { x ->
            val u = area.left + (area.right - area.left) * (x + .5f) / SignatureWidth
            val v = area.top + (area.bottom - area.top) * (y + .5f) / SignatureHeight
            bitmap.getPixel((u * bitmap.width).toInt().coerceIn(0, bitmap.width - 1),
                (v * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)) and 0xffffff
        }
    }

private fun sampleColor(bitmap: Bitmap, area: Area): Int {
    val colors = signature(bitmap, area)
    fun median(channel: (Int) -> Int) = colors.map(channel).sorted()[colors.size / 2]
    return Color.rgb(median(Color::red), median(Color::green), median(Color::blue))
}

fun Calibration.score(mark: Mark, bitmap: Bitmap): Float {
    val reference = marks[mark] ?: return 0f
    if (reference.values.size != SignatureWidth * SignatureHeight) return 0f
    val next = signature(bitmap, reference.area)
    var difference = 0
    for (index in next.indices) {
        val a = next[index]
        val b = reference.values[index]
        difference += abs(Color.red(a) - Color.red(b)) +
            abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))
    }
    return 1f - difference.toFloat() / (next.size * 765)
}

class CalibrationStore(context: Context) {
    private val disk = context.getSharedPreferences("visual-calibration", Context.MODE_PRIVATE)

    fun read(): Calibration = runCatching {
        val root = JSONObject(disk.getString("marks", "{}") ?: "{}")
        val jsonMarks = root.optJSONObject("marks") ?: JSONObject()
        val entries = Mark.entries.mapNotNull { mark ->
            val entry = jsonMarks.optJSONObject(mark.name) ?: return@mapNotNull null
            val a = entry.getJSONArray("area")
            val v = entry.getJSONArray("values")
            mark to Reference(Area(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(),
                a.getDouble(2).toFloat(), a.getDouble(3).toFloat()), List(v.length()) { v.getInt(it) })
        }.toMap()
        Calibration(root.optString("fighter"), root.optDouble("aspect", 0.0).toFloat(), entries)
    }.getOrDefault(Calibration())

    fun write(value: Calibration) {
        val marks = JSONObject()
        for ((key, reference) in value.marks) {
            val a = reference.area
            marks.put(key.name, JSONObject().put("area", JSONArray(listOf(a.left, a.top, a.right, a.bottom)))
                .put("values", JSONArray(reference.values)))
        }
        disk.edit().putString("marks", JSONObject().put("fighter", value.fighter)
            .put("aspect", value.aspect).put("marks", marks).toString()).apply()
    }
}
