package pilot.app

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import pilot.data.*
import pilot.domain.*
import pilot.engine.Arena
import pilot.engine.ArenaFrame
import pilot.engine.Session
import pilot.screen.LiveBus
import pilot.vision.*
import kotlin.math.max

data class SimView(
    val phase: Phase = Phase.IDLE,
    val frame: ArenaFrame? = null,
    val report: Report? = null,
    val message: String = "Готов к запуску"
) {
    val active get() = phase != Phase.IDLE && phase != Phase.DONE
}

class PilotModel(private val context: Application) : AndroidViewModel(context) {
    private val settings = Settings(context)
    private val catalog = Catalog(context)
    private val history = History.get(context)
    private val calibrationDisk = CalibrationStore(context)
    private val saves = Channel<Preferences>(Channel.CONFLATED)
    val preferences = MutableStateFlow(Preferences())
    val loaded = MutableStateFlow(false)
    val fighters = MutableStateFlow(Profiles.available.map { it.name })
    val refreshing = MutableStateFlow(false)
    val calibration = MutableStateFlow(calibrationDisk.read())
    val reports = history.recent.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
    val live = LiveBus.status
    val snapshot = LiveBus.snapshot
    val imported = MutableStateFlow<Bitmap?>(null)
    val offline = MutableStateFlow<Observation?>(null)
    val message = MutableStateFlow("")
    val sim = MutableStateFlow(SimView())
    private var simSession: Session? = null
    private var importJob: Job? = null
    private var scanJob: Job? = null

    init {
        LiveBus.restoreDiagnostics(context)
        viewModelScope.launch {
            try { preferences.value = settings.values.first() }
            catch (_: Exception) { message.value = "Настройки не удалось прочитать" }
            loaded.value = true
            for (value in saves) {
                try { settings.save(value) }
                catch (cancel: CancellationException) { throw cancel }
                catch (_: Exception) { message.value = "Не удалось сохранить настройки" }
            }
        }
        viewModelScope.launch {
            fighters.value = runCatching { catalog.names() }.getOrDefault(fighters.value)
        }
    }

    fun change(transform: (Preferences) -> Preferences) {
        if (!loaded.value) return
        val next = transform(preferences.value)
        preferences.value = next
        saves.trySend(next)
    }

    fun refreshCatalog() {
        if (refreshing.value) return
        refreshing.value = true
        viewModelScope.launch {
            try { fighters.value = catalog.refresh(); message.value = "Каталог обновлён · ${fighters.value.size} бойцов" }
            catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { message.value = "Каталог недоступен. Можно пользоваться сохранённым списком" }
            finally { refreshing.value = false }
        }
    }

    fun configuration(): Configuration? {
        if (!loaded.value) return null
        val value = preferences.value
        val profile = Profiles.find(value.fighter)
        if (profile == null) {
            message.value = "Для этого бойца пока нет боевого профиля"
            return null
        }
        return Configuration(value.fighter, profile, value.goal, value.mode, value.options)
    }

    fun startSimulator(initial: Int) {
        if (sim.value.active || live.value.active) return
        val configuration = configuration() ?: return
        val session = Session(configuration, Source.SIMULATOR, initial)
        simSession = session
        val arena = Arena(configuration, 1)
        publish(session, arena.frame(), "Тестовая арена")
        viewModelScope.launch {
            var current = arena
            var end = current.frame()
            val interval = 65L
            while (session.timeCheck(System.currentTimeMillis())) {
                if (session.phase == Phase.PAUSED) {
                    delay(125)
                    continue
                }
                when (session.phase) {
                    Phase.HOME -> session.step(Phase.BRAWLER_SELECTION)
                    Phase.BRAWLER_SELECTION -> session.step(Phase.MODE_SELECTION)
                    Phase.MODE_SELECTION, Phase.NEXT_MATCH -> {
                        current = Arena(configuration, session.round + 1)
                        end = current.frame()
                        session.step(Phase.MATCHMAKING)
                    }
                    Phase.MATCHMAKING -> session.step(Phase.LOADING)
                    Phase.LOADING -> session.step(Phase.IN_MATCH)
                    Phase.IN_MATCH -> {
                        end = withContext(Dispatchers.Default) { current.tick(.12f) }
                        if (end.result != null && session.phase == Phase.IN_MATCH) session.step(Phase.RESULTS)
                    }
                    Phase.RESULTS -> session.step(Phase.TROPHY_CHECK)
                    Phase.TROPHY_CHECK -> {
                        val outcome = end.result ?: Result.UNKNOWN
                        val delta = if (outcome == Result.WIN) 8 else if (outcome == Result.LOSS) -4 else 0
                        session.record(max(0, session.report.current + delta), outcome, System.currentTimeMillis())
                        saveReport(session)
                    }
                    else -> Unit
                }
                publish(session, end, if (session.phase == Phase.IN_MATCH) end.decision.reason else phaseLabel(session.phase))
                delay(if (session.phase == Phase.RESULTS) 450 else interval)
            }
            publish(session, end, session.message)
            saveReport(session)
            if (session.message == "Цель достигнута") notifyGoal(session.report)
        }
    }

    fun pauseSimulator() {
        val session = simSession ?: return
        if (session.phase == Phase.PAUSED) session.resume(System.currentTimeMillis()) else session.pause("Пауза")
        publish(session, sim.value.frame, phaseLabel(session.phase))
    }

    fun stopSimulator() {
        val session = simSession ?: return
        session.stop("Остановлено вручную")
        publish(session, sim.value.frame, session.message)
    }

    private suspend fun saveReport(session: Session) {
        try { history.save(session.report, session.message) }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { message.value = "Не удалось сохранить сессию" }
    }

    private fun publish(session: Session, frame: ArenaFrame?, label: String) {
        val old = sim.value
        if (old.report != null && old.report.id != session.report.id && simSession !== session) return
        sim.value = SimView(session.phase, frame, session.report, session.message.ifBlank { label })
    }

    private fun notifyGoal(report: Report) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("arena-goal", "Цели симулятора", NotificationManager.IMPORTANCE_DEFAULT))
        manager.notify(23, Notification.Builder(context, "arena-goal")
            .setSmallIcon(android.R.drawable.star_on).setContentTitle("Тестовая цель достигнута")
            .setContentText("${report.configuration.fighter} · ${report.current} условных кубков")
            .setAutoCancel(true).build())
    }

    fun mark(mark: Mark, frame: Bitmap, area: Area) {
        runCatching {
            calibration.value.add(preferences.value.fighter, mark, frame, area)
        }.onSuccess {
            calibrationDisk.write(it)
            calibration.value = it
            offline.value = null
            message.value = "Сохранено · ${mark.title}"
        }.onFailure { message.value = it.message ?: "Область не сохранена" }
    }

    fun resetCalibration() {
        calibration.value = Calibration()
        calibrationDisk.write(calibration.value)
        offline.value = null
    }

    fun import(uri: Uri, fraction: Float = .5f) {
        importJob?.cancel()
        scanJob?.cancel()
        offline.value = null
        importJob = viewModelScope.launch {
            try {
                imported.value = withContext(Dispatchers.IO) {
                    val bitmap = if (context.contentResolver.getType(uri)?.startsWith("video/") == true) {
                        val retriever = MediaMetadataRetriever()
                        try {
                            retriever.setDataSource(context, uri)
                            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                                ?: error("Не читается длительность")
                            val time = (duration * 1000 * fraction.toDouble()).toLong()
                            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
                            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
                            val ratio = minOf(1f, 1280f / max(width, height).coerceAtLeast(1))
                            retriever.getScaledFrameAtTime(time, MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                                (width * ratio).toInt().coerceAtLeast(1), (height * ratio).toInt().coerceAtLeast(1))
                        } finally { retriever.release() }
                    } else {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                        val options = BitmapFactory.Options().apply {
                            inSampleSize = (max(bounds.outWidth, bounds.outHeight) / 1400).coerceAtLeast(1)
                            inPreferredConfig = Bitmap.Config.ARGB_8888
                        }
                        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                    } ?: error("Не удалось открыть кадр")
                    val ratio = 960f / max(bitmap.width, bitmap.height)
                    if (ratio < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(),
                        (bitmap.height * ratio).toInt(), true).also { if (it !== bitmap) bitmap.recycle() }
                    else bitmap
                }
            } catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { message.value = "Файл не удалось открыть. Поддерживаются изображения и локальные видео" }
        }
    }

    fun inspect(frame: Bitmap) {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            try {
                val config = calibration.value
                check(config.comparable(frame)) { "Пропорции кадра отличаются от калибровки" }
                val threshold = preferences.value.options.confidence
                val (visionResult, trophies) = withContext(Dispatchers.Default) {
                    FrameVision().use { vision ->
                        vision.inspect(frame, config, threshold, .2f) to
                            config.marks[Mark.TROPHIES]?.let { vision.trophies(frame, it) }
                    }
                }
                offline.value = visionResult
                message.value = "Распознавание · боец ${if (visionResult.world?.self != null) "найден" else "—"} · цифры ${trophies ?: "—"}"
            } catch (cancel: CancellationException) { throw cancel }
            catch (error: Exception) { message.value = error.message ?: "Кадр не распознан" }
        }
    }
}

fun phaseLabel(phase: Phase) = when (phase) {
    Phase.IDLE -> "Готов к запуску"
    Phase.HOME -> "Лобби"
    Phase.BRAWLER_SELECTION -> "Выбор бойца"
    Phase.MODE_SELECTION -> "Режим выбран"
    Phase.MATCHMAKING -> "Поиск матча"
    Phase.LOADING -> "Загрузка"
    Phase.IN_MATCH -> "В матче"
    Phase.RESULTS -> "Результат"
    Phase.TROPHY_CHECK -> "Проверка кубков"
    Phase.NEXT_MATCH -> "Следующий матч"
    Phase.PAUSED -> "Пауза"
    Phase.DONE -> "Завершено"
}
