package pilot.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pilot.data.SavedReport
import pilot.domain.*
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun EngineSettings(model: PilotModel, options: Options, enabled: Boolean) {
    fun change(update: (Options) -> Options) = model.change { it.copy(options = update(it.options)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassPanel {
            Micro("AI SETTINGS", Cyan)
            Heading("Стиль игры")
            if (!enabled) Hint("Заверши сессию, чтобы изменить параметры.", Rose)
            PlayStyle.entries.forEach { style ->
                GlassButton(style.label, { change { it.copy(style = style) } }, Modifier.fillMaxWidth(),
                    primary = style == options.style, enabled = enabled)
            }
            Hint(when (options.style) {
                PlayStyle.SAFE -> "Отходит при снижении здоровья до 56%."
                PlayStyle.BALANCED -> "Отходит при снижении здоровья до 38%."
                PlayStyle.AGGRESSIVE -> "Отходит при снижении здоровья до 23%."
            })
        }
        GlassPanel {
            Heading("Лимиты")
            OptionSlider("Лимит времени", "${options.seconds / 60} мин", (options.seconds / 60).toFloat(), 1f..60f, 58, enabled) {
                change { value -> value.copy(seconds = it.roundToInt() * 60) }
            }
            OptionSlider("Лимит матчей", options.matchLimit.toString(), options.matchLimit.toFloat(), 1f..50f, 48, enabled) {
                change { value -> value.copy(matchLimit = it.roundToInt()) }
            }
        }
        GlassPanel {
            Heading("Захват и распознавание")
            OptionSlider("Частота анализа", "${options.fps} кадр/с", options.fps.toFloat(), 2f..12f, 9, enabled) {
                change { value -> value.copy(fps = it.roundToInt()) }
            }
            OptionSlider("Минимальная уверенность", "${(options.confidence * 100).roundToInt()}%", options.confidence,
                .55f.. .98f, 42, enabled) { change { value -> value.copy(confidence = it) } }
            OptionSwitch("Рамки распознавания", options.debugBoxes, enabled) { change { value -> value.copy(debugBoxes = it) } }
            OptionSwitch("Журнал диагностики", options.diagnostics, enabled) { change { value -> value.copy(diagnostics = it) } }
            OptionSwitch("Пауза при сбое распознавания", options.autoPause, enabled) { change { value -> value.copy(autoPause = it) } }
            Hint("Если автоматическая пауза выключена, при длительной потере изображения сессия завершается.")
        }
    }
}

@Composable
private fun OptionSlider(label: String, value: String, current: Float, range: ClosedFloatingPointRange<Float>,
    steps: Int, enabled: Boolean, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Hint(label)
            Micro(value, Cyan)
        }
        Slider(current, onChange, enabled = enabled, valueRange = range, steps = steps)
    }
}

@Composable
private fun OptionSwitch(label: String, value: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { Hint(label) }
        Switch(value, onChange, enabled = enabled)
    }
}

@Composable
fun AnalyticsScreen(reports: List<SavedReport>) {
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var source by rememberSaveable { mutableStateOf(Source.SIMULATOR.name) }
    val currentReports = reports.filter { it.source == source }
    val report = currentReports.firstOrNull { it.id == selected } ?: currentReports.firstOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassPanel {
            Micro("FARM ANALYTICS", Cyan)
            Heading("История сессий")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Симулятор", { source = Source.SIMULATOR.name }, Modifier.weight(1f),
                    primary = source == Source.SIMULATOR.name)
                GlassButton("Brawl Stars", { source = Source.GAME.name }, Modifier.weight(1f), primary = source == Source.GAME.name)
            }
            if (report == null) Hint("У этого режима пока нет сохранённых сессий.")
        }
        if (report != null) {
            val rounds = remember(report) { report.rounds() }
            val delta = report.current - report.initial
            val wins = rounds.count { it.result == Result.WIN }
            val losses = rounds.count { it.result == Result.LOSS }
            val minutes = ((report.updated - report.started) / 60000).coerceAtLeast(0)
            val seconds = ((report.updated - report.started) / 1000 % 60).coerceAtLeast(0)
            GlassPanel {
                Micro(if (source == Source.SIMULATOR.name) "ТЕСТОВАЯ СЕССИЯ" else "ИГРОВАЯ СЕССИЯ", Lavender)
                Heading(report.fighter)
                Hint("${report.mode} · ${report.reason.ifBlank { "Последняя сохранённая отметка" }}")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("КУБКИ", "${report.initial} → ${report.current}")
                    Metric("ИЗМЕНЕНИЕ", if (delta > 0) "+$delta" else delta.toString())
                }
                Trend(listOf(report.initial) + rounds.map { it.trophies }, report.id)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("МАТЧИ", rounds.size.toString())
                    Metric("ПОБЕДЫ", wins.toString())
                    Metric("ПОРАЖЕНИЯ", losses.toString())
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("ЦЕЛЬ", report.goal.toString())
                    Metric("ДЛИТЕЛЬНОСТЬ", String.format(Locale.ROOT, "%d:%02d", minutes, seconds))
                    Metric("ЗА МАТЧ", if (rounds.isEmpty()) "—" else String.format(Locale.ROOT, "%+.1f", delta.toDouble() / rounds.size))
                }
            }
            if (rounds.isNotEmpty()) GlassPanel {
                Heading("Матчи")
                rounds.takeLast(12).asReversed().forEachIndexed { index, battle ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Hint("${rounds.size - index} · " + when (battle.result) {
                            Result.WIN -> "Победа"
                            Result.LOSS -> "Поражение"
                            Result.DRAW -> "Ничья"
                            Result.UNKNOWN -> "Не определён"
                        })
                        Micro(battle.trophies.toString(), Cyan)
                    }
                }
            }
            GlassPanel {
                Heading("Сохранённые сессии")
                currentReports.forEach {
                    val date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(it.started))
                    GlassButton("${it.fighter} · ${it.current} · $date", { selected = it.id },
                        Modifier.fillMaxWidth(), primary = report.id == it.id)
                }
            }
        }
    }
}

@Composable
private fun Metric(title: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Micro(title)
        Text(value, color = White, fontFamily = FontFamily.Monospace, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Trend(values: List<Int>, identity: String) {
    var started by remember(identity, values.size) { mutableStateOf(false) }
    LaunchedEffect(identity, values.size) { started = true }
    val shown by animateFloatAsState(if (started) 1f else 0f, tween(500), label = "график")
    Canvas(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(12.dp)).background(Night)) {
        val top = 14.dp.toPx()
        val bottom = size.height - top
        val min = values.min() - 3
        val max = values.max() + 3
        val left = 9.dp.toPx()
        val right = size.width - left
        for (i in 0..3) {
            val y = top + i * (bottom - top) / 3
            drawLine(Line, Offset(left, y), Offset(right, y), 1.dp.toPx())
        }
        val count = values.lastIndex.coerceAtLeast(1)
        val points = values.mapIndexed { i, value -> Offset(left + (right - left) * i / count,
            bottom - (bottom - top) * (value - min) / (max - min)) }
        if (values.size == 1) drawLine(Cyan, points.first(), Offset(right, points.first().y), 2.dp.toPx(), StrokeCap.Round)
        else {
            val shownSegments = shown * count
            val visible = mutableListOf(points.first())
            for (i in 1..count) {
                val proportion = (shownSegments - (i - 1)).coerceIn(0f, 1f)
                if (proportion == 0f) break
                visible += points[i - 1] + (points[i] - points[i - 1]) * proportion
            }
            val fill = Path().apply {
                moveTo(visible.first().x, bottom)
                visible.forEach { lineTo(it.x, it.y) }
                lineTo(visible.last().x, bottom)
                close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(Lavender.copy(alpha = .32f), Lavender.copy(alpha = 0f))))
            visible.zipWithNext { a, b -> drawLine(Cyan, a, b, 2.dp.toPx(), StrokeCap.Round) }
            drawCircle(White, 3.dp.toPx(), visible.last())
        }
    }
}
