package pilot.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Night = Color(0xFF0D0B16)
val GlassTop = Color(0xFF26203B)
val GlassLow = Color(0xFF171425)
val Lavender = Color(0xFFBBABFF)
val Cyan = Color(0xFF7EE6FF)
val Mint = Color(0xFF72F2BC)
val Rose = Color(0xFFFF9FBE)
val White = Color(0xFFF6F2FF)
val Muted = Color(0xFFB0A9C2)
val Line = Color(0xFF39314F)
private val PanelShape = RoundedCornerShape(26.dp)
private val PillShape = RoundedCornerShape(17.dp)

@Composable
fun PilotTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Lavender, secondary = Cyan, background = Night, surface = GlassLow,
        onBackground = White, onSurface = White, onSurfaceVariant = Muted, outline = Line
    ), content = content)
}

@Composable
fun Atmosphere(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.width
        drawRect(Night)
        drawRect(Brush.radialGradient(listOf(Color(0xFF302057), Night.copy(alpha = 0f)),
            center = Offset(s * .88f, size.height * .14f), radius = s * .81f))
        drawRect(Brush.radialGradient(listOf(Color(0xFF15263F), Night.copy(alpha = 0f)),
            center = Offset(s * .09f, size.height * .60f), radius = s * .67f))
    }
}

@Composable
fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(PanelShape)
        .background(Brush.linearGradient(listOf(GlassTop.copy(alpha = .95f), GlassLow.copy(alpha = .91f))))
        .border(1.dp, Brush.linearGradient(listOf(Color(0xFF574A76), Color(0xFF29233A), Color(0xFF3F3659))), PanelShape)
        .padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
fun Micro(text: String, color: Color = Muted, modifier: Modifier = Modifier) {
    Text(text, color = color, modifier = modifier,
        style = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            fontSize = 10.sp, letterSpacing = 1.1.sp, lineHeight = 15.sp))
}

@Composable
fun Heading(text: String) {
    Text(text, fontSize = 21.sp, lineHeight = 26.sp, letterSpacing = (-.7).sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Hint(text: String, color: Color = Muted) {
    Text(text, color = color, fontSize = 13.sp, lineHeight = 19.sp)
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true,
    tone: Color = Lavender
) {
    val fill = if (!enabled) Brush.linearGradient(listOf(GlassTop, GlassTop)) else if (primary)
        Brush.horizontalGradient(listOf(Color(0xFF9470F3), Color(0xFFC2A6FF), Color(0xFF8DCCFC)))
    else Brush.linearGradient(listOf(tone.copy(alpha = .15f), tone.copy(alpha = .045f)))
    Box(modifier.clip(PillShape).background(fill)
        .border(1.dp, tone.copy(alpha = if (enabled) .31f else .13f), PillShape)
        .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        .defaultMinSize(minHeight = if (primary) 53.dp else 44.dp).padding(horizontal = 12.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center) {
        Text(text, color = if (!enabled) Muted else if (primary) Night else tone,
            fontWeight = FontWeight.Bold, fontSize = 13.sp, lineHeight = 18.sp,
            style = LocalTextStyle.current.copy(textAlign = androidx.compose.ui.text.style.TextAlign.Center))
    }
}

@Composable
fun StatusPill(text: String, running: Boolean) {
    val indicator = if (running) Mint else Lavender
    Row(Modifier.clip(RoundedCornerShape(50)).background(indicator.copy(alpha = .11f))
        .border(1.dp, indicator.copy(alpha = .25f), RoundedCornerShape(50))
        .padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).background(indicator, RoundedCornerShape(50)))
        Spacer(Modifier.width(6.dp))
        Micro(text, indicator)
    }
}

@Composable
fun Logo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * .50f, h * .08f); lineTo(w * .92f, h * .80f); lineTo(w * .50f, h * .65f)
            lineTo(w * .08f, h * .80f); close()
        }
        drawPath(path, Brush.linearGradient(listOf(Cyan, Lavender, Color(0xFF9771FF))))
        val inlay = Path().apply {
            moveTo(w * .5f, h * .33f); lineTo(w * .64f, h * .57f)
            lineTo(w * .5f, h * .53f); lineTo(w * .36f, h * .57f); close()
        }
        drawPath(inlay, Color(0xFFF7EEFF))
    }
}

@Composable
fun Radar(active: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "радар")
    val sweep by transition.animateFloat(0f, 360f,
        infiniteRepeatable(tween(if (active) 3700 else 9000, easing = LinearEasing)), label = "луч")
    Canvas(modifier) {
        val r = size.minDimension / 2
        val center = Offset(size.width / 2, size.height / 2)
        val tint = if (active) Cyan else Lavender
        drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = .26f), tint.copy(alpha = 0f)), center, r), r)
        for (factor in listOf(.31f, .51f, .73f, .94f))
            drawCircle(tint.copy(alpha = .28f), r * factor, center, style = Stroke(1.dp.toPx()))
        for (index in 0 until 24) {
            val angle = index * PI / 12
            val direction = Offset(cos(angle).toFloat(), sin(angle).toFloat())
            drawLine(tint.copy(alpha = if (index % 6 == 0) .55f else .24f),
                center + direction * (r * .81f), center + direction * (r * .87f), 1.dp.toPx())
        }
        val arcOrigin = center - Offset(.73f * r, .73f * r)
        val diameter = 1.46f * r
        drawArc(tint.copy(alpha = .10f), sweep - 38, 38f, true, topLeft = arcOrigin,
            size = Size(diameter, diameter))
        drawArc(tint, sweep - 29, 29f, false, topLeft = arcOrigin, size = Size(diameter, diameter),
            style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(tint.copy(alpha = .65f), r * .035f, center + Offset(r * .37f, -r * .46f))
        drawCircle(tint.copy(alpha = .6f), r * .025f, center + Offset(-r * .44f, r * .28f))
    }
    Box(modifier, contentAlignment = Alignment.Center) { Logo(Modifier.size(35.dp)) }
}
