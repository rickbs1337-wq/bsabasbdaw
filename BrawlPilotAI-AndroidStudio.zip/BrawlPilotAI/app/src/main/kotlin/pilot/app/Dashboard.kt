package pilot.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pilot.data.Preferences
import pilot.domain.*
import pilot.engine.ArenaFrame
import pilot.screen.LiveStatus

@Composable
fun Dashboard(
    model: PilotModel, settings: Preferences, sim: SimView, live: LiveStatus, ready: Boolean, game: Boolean,
    onSource: (Boolean) -> Unit, onSettings: () -> Unit, onStart: (Int) -> Unit, onPause: () -> Unit, onStop: () -> Unit
) {
    val reports by model.reports.collectAsStateWithLifecycle()
    val calibration by model.calibration.collectAsStateWithLifecycle()
    val phase = if (game) live.phase else sim.phase
    val active = if (game) live.active else sim.active
    val locked = sim.active || live.active
    val last = if (game) live.report else sim.report
    val report = last?.takeIf { it.configuration.fighter == settings.fighter }
    val stored = reports.firstOrNull { it.source == Source.SIMULATOR.name && it.fighter == settings.fighter }
    val original = if (game) report?.current else report?.current ?: stored?.current ?: 450
    val target = if (active) report?.configuration?.target ?: settings.goal else settings.goal
    val fraction by animateFloatAsState((original?.toFloat()?.div(target) ?: 0f).coerceIn(0f, 1f), spring(), label = "цель")
    var fighterModal by rememberSaveable { mutableStateOf(false) }
    var modeModal by rememberSaveable { mutableStateOf(false) }
    var goalText by rememberSaveable(settings.goal) { mutableStateOf(settings.goal.toString()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)
        .widthIn(max = 760.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassPanel {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Micro("AI FARM CONTROL", Cyan)
                    Text("Пульт\nсессии", fontSize = 43.sp, lineHeight = 42.sp, letterSpacing = (-2.1).sp,
                        fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    val configured = !game || live.capturing && calibration.missing.isEmpty() && calibration.fighter == settings.fighter
                    StatusPill(if (phase == Phase.DONE || active) phaseLabel(phase) else if (configured) "AI READY" else "SETUP", active)
                }
                Box(Modifier.size(128.dp), contentAlignment = Alignment.Center) { Radar(active && phase != Phase.PAUSED, Modifier.fillMaxSize()) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Симулятор", { onSource(false) }, Modifier.weight(1f), primary = !game, enabled = !locked)
                GlassButton("Brawl Stars", { onSource(true) }, Modifier.weight(1f), primary = game, enabled = !locked)
            }
        }
        GlassPanel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Micro(if (game) "КУБКИ В ИГРЕ" else "УСЛОВНЫЕ КУБКИ", Lavender)
                    Text(original?.toString() ?: "—", fontFamily = FontFamily.Monospace, fontSize = 39.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Micro("ЦЕЛЬ", Cyan)
                    Text(target.toString(), color = Cyan, fontFamily = FontFamily.Monospace, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                }
            }
            val barShape = RoundedCornerShape(50)
            Box(Modifier.fillMaxWidth().height(7.dp).clip(barShape).background(Line)) {
                Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(barShape)
                    .background(Brush.horizontalGradient(listOf(Color(0xFFA28CFF), Cyan))))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (game) live.message else sim.message, color = Muted, fontSize = 13.sp,
                    lineHeight = 19.sp, modifier = Modifier.weight(1f).padding(end = 6.dp))
                if (original != null) Micro("${(fraction * 100 + .5f).toInt()}%", Mint)
            }
        }
        if (active) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(if (phase == Phase.PAUSED) "Продолжить" else "Пауза", onPause, Modifier.weight(1f))
                GlassButton("■  STOP FARM", onStop, Modifier.weight(1f), tone = Rose)
            }
        } else {
            GlassButton("▶   START FARM", { onStart(original ?: 0) }, Modifier.fillMaxWidth(), primary = true,
                enabled = ready && !locked && Profiles.find(settings.fighter) != null &&
                    goalText.toIntOrNull()?.let { it > 0 } == true && (!game || settings.mode == Mode.SURVIVAL))
        }
        if (!locked) GlassPanel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(settings.fighter + "  ▾", { fighterModal = true }, Modifier.weight(1f))
                GlassButton(settings.mode.label + "  ▾", { modeModal = true }, Modifier.weight(1f))
            }
            OutlinedTextField(goalText, { value ->
                if (value.length <= 6 && value.all(Char::isDigit)) {
                    goalText = value
                    value.toIntOrNull()?.takeIf { it > 0 }?.let { goal -> model.change { it.copy(goal = goal) } }
                }
            }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Цель по кубкам") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), shape = RoundedCornerShape(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (quick in listOf(500, 750, 1000, 1250)) {
                    GlassButton(quick.toString(), { goalText = quick.toString(); model.change { it.copy(goal = quick) } },
                        Modifier.weight(1f), tone = if (quick == target) Cyan else Lavender)
                }
            }
            val profile = Profiles.find(settings.fighter)
            if (profile == null) Hint("Боевой профиль для этого бойца в разработке.", Rose)
            if (game && settings.mode != Mode.SURVIVAL) Hint("В Brawl Stars этот режим пока недоступен. Его можно проверить на арене.", Rose)
            if (game && !live.capturing) GlassButton("Подключить захват и жесты", onSettings, Modifier.fillMaxWidth())
        }
        if (!game && sim.frame != null) {
            GlassPanel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Heading("Тестовая арена")
                    Micro("${sim.frame.time.toInt()} С", Cyan)
                }
                ArenaMap(sim.frame, settings.options.debugBoxes)
                Hint("Задачи за раунд: ${sim.frame.objectives} · ${sim.frame.decision.reason}")
            }
        }
        if (game && settings.options.debugBoxes) live.debug?.let { world ->
            GlassPanel {
                Heading("Обнаруженные объекты")
                ArenaMap(ArenaFrame(world), true)
            }
        }
        if (report != null && phase == Phase.DONE) GlassPanel {
            Micro("ИТОГ СЕССИИ", Mint)
            Text("${report.initial} → ${report.current} кубков", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Hint("${report.battles.size} матчей · ${report.battles.count { it.result == Result.WIN }} побед")
        }
        Spacer(Modifier.height(6.dp))
    }
    if (fighterModal) FighterPicker(model, settings, { fighterModal = false }) { name ->
        model.change { it.copy(fighter = name) }
        fighterModal = false
    }
    if (modeModal) AlertDialog(onDismissRequest = { modeModal = false }, title = { Heading("Режим") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Mode.entries.forEach { mode ->
                    GlassButton(mode.label + if (game && mode != Mode.SURVIVAL) " · арена" else "", {
                        model.change { it.copy(mode = mode) }
                        modeModal = false
                    }, Modifier.fillMaxWidth(), primary = mode == settings.mode)
                }
            }
        }, confirmButton = { TextButton({ modeModal = false }) { Text("Закрыть") } })
}

@Composable
private fun FighterPicker(model: PilotModel, settings: Preferences, dismiss: () -> Unit, select: (String) -> Unit) {
    val catalog by model.fighters.collectAsStateWithLifecycle()
    val refreshing by model.refreshing.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableIntStateOf(0) }
    val matches = remember(catalog, query, sort, settings.favorites) {
        val all = catalog.filter { it.contains(query.trim(), ignoreCase = true) || (query.isBlank() && it in settings.favorites) }
        when (sort) {
            1 -> all.filter { it in settings.favorites }
            2 -> all.sortedByDescending { it.lowercase() }
            else -> all.sortedWith(compareByDescending<String> { Profiles.find(it) != null }.thenBy { it.lowercase() })
        }
    }
    AlertDialog(onDismissRequest = dismiss, title = { Heading("Бойцы") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Имя бойца") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    GlassButton(listOf("По профилю", "Избранное", "Я → А")[sort], { sort = (sort + 1) % 3 }, Modifier.weight(1f))
                    GlassButton(if (refreshing) "Обновление" else "Обновить", model::refreshCatalog, Modifier.weight(1f), enabled = !refreshing)
                }
                if (matches.isEmpty()) Hint("Бойцы не найдены")
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(matches, key = { it }) { name ->
                        val isFavorite = name in settings.favorites
                        val hasProfile = Profiles.find(name) != null
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(34.dp).border(1.dp, Line, CircleShape).background(GlassTop, CircleShape),
                                contentAlignment = Alignment.Center) { Text(name.take(1), color = Cyan, fontWeight = FontWeight.Bold) }
                            Column(Modifier.weight(1f).clickable { select(name) }.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                Text(name, fontWeight = FontWeight.SemiBold, color = if (settings.fighter == name) Cyan else White)
                                Hint(if (hasProfile) "Профиль доступен" else "Профиль в разработке")
                            }
                            IconButton({
                                model.change { it.copy(favorites = if (isFavorite) it.favorites - name else it.favorites + name) }
                            }) { Text(if (isFavorite) "★" else "☆", color = Lavender, fontSize = 25.sp) }
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(dismiss) { Text("Закрыть") } })
}

@Composable
fun ArenaMap(frame: ArenaFrame, box: Boolean) {
    Canvas(Modifier.fillMaxWidth().aspectRatio(1.58f).clip(RoundedCornerShape(17.dp))
        .background(Color(0xFF101325)).border(1.dp, Line, RoundedCornerShape(17.dp))) {
        fun point(v: Vec) = Offset(v.x * size.width, v.y * size.height)
        for (i in 1..13) {
            val x = size.width * i / 14
            drawLine(Line.copy(alpha = .53f), Offset(x, 0f), Offset(x, size.height))
        }
        for (i in 1..8) {
            val y = size.height * i / 9
            drawLine(Line.copy(alpha = .53f), Offset(0f, y), Offset(size.width, y))
        }
        for (danger in frame.world.danger) {
            drawRect(Rose.copy(alpha = .19f), point(Vec(danger.left, danger.top)),
                Size((danger.right - danger.left) * size.width, (danger.bottom - danger.top) * size.height))
        }
        for (wall in frame.world.walls) {
            val top = point(Vec(wall.left, wall.top))
            val bounds = Size((wall.right - wall.left) * size.width, (wall.bottom - wall.top) * size.height)
            drawRect(Color(0xFF2C2844), top, bounds)
            drawRect(Lavender.copy(alpha = .40f), top, bounds, style = Stroke(1.dp.toPx()))
        }
        frame.world.goal?.let { drawCircle(Cyan, 13.dp.toPx(), point(it), style = Stroke(1.5.dp.toPx())) }
        frame.world.ball?.let { drawCircle(White, 5.dp.toPx(), point(it)) }
        frame.world.gems?.let { drawCircle(Lavender, 6.dp.toPx(), point(it)) }
        val radius = 7.dp.toPx()
        fun actor(value: Actor, color: Color) {
            val center = point(value.point)
            drawCircle(color.copy(alpha = .20f), radius * 1.55f, center)
            drawCircle(color, radius, center)
            value.health?.let {
                val start = center + Offset(-radius, -radius - 6.dp.toPx())
                drawLine(color.copy(alpha = .25f), start, start + Offset(radius * 2, 0f), 2.dp.toPx(), StrokeCap.Round)
                drawLine(color, start, start + Offset(radius * 2 * it.coerceIn(0f, 1f), 0f), 2.dp.toPx(), StrokeCap.Round)
            }
            if (box) drawRect(color, center - Offset(radius * 1.2f, radius * 1.2f),
                Size(radius * 2.4f, radius * 2.4f), style = Stroke(1.dp.toPx()))
        }
        frame.world.allies.forEach { actor(it, Mint) }
        frame.world.enemies.forEach { actor(it, Rose) }
        frame.world.self?.let { self ->
            actor(self, Cyan)
            frame.hit?.let { drawLine(Lavender, point(self.point), point(it), 2.dp.toPx(), StrokeCap.Round) }
        }
    }
}
