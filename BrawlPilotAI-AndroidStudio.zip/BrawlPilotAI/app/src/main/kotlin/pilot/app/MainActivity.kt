package pilot.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pilot.screen.LiveBus
import pilot.screen.PilotGestures
import pilot.screen.ProjectionService

class MainActivity : ComponentActivity() {
    private val model by viewModels<PilotModel>()
    private var permissionRevision by mutableIntStateOf(0)
    private var fileRevision by mutableIntStateOf(0)
    private var importedFile: Uri? = null
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            runCatching { ProjectionService.begin(this, data) }
                .onFailure { model.message.value = "Android отказал в запуске захвата" }
        } else model.message.value = "Захват экрана отменён"
    }
    private var requestCaptureAfterNotifications = false
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (requestCaptureAfterNotifications) {
            requestCaptureAfterNotifications = false
            projection.launch(ProjectionService.consentIntent(this))
        }
    }
    private val file = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importedFile = uri
            fileRevision++
            model.import(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            PilotTheme {
                var tab by rememberSaveable { mutableIntStateOf(0) }
                var source by rememberSaveable { mutableStateOf(false) }
                val pref by model.preferences.collectAsStateWithLifecycle()
                val sim by model.sim.collectAsStateWithLifecycle()
                val live by model.live.collectAsStateWithLifecycle()
                val report by model.reports.collectAsStateWithLifecycle()
                val message by model.message.collectAsStateWithLifecycle()
                val ready by model.loaded.collectAsStateWithLifecycle()
                val snackbar = remember { SnackbarHostState() }
                val haptics = LocalHapticFeedback.current
                LaunchedEffect(message) {
                    if (message.isNotBlank()) {
                        snackbar.showSnackbar(message)
                        if (model.message.value == message) model.message.value = ""
                    }
                }
                Box(Modifier.fillMaxSize()) {
                    Atmosphere(Modifier.matchParentSize())
                    Scaffold(containerColor = Color.Transparent, contentColor = White, snackbarHost = { SnackbarHost(snackbar) },
                        topBar = {
                            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 22.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Logo(Modifier.size(28.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("BRAWLPILOT", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                                        Micro("AI", Cyan)
                                    }
                                    Text("Your Intelligent Farming Assistant", fontSize = 10.sp, color = Muted)
                                }
                                IconButton({ tab = 2 }) { Icon(Icons.Default.Settings, "Настройки", tint = Lavender) }
                            }
                        }, bottomBar = {
                            NavigationBar(containerColor = GlassLow) {
                                val tabs = listOf("Пульт" to Icons.Default.Home, "История" to Icons.AutoMirrored.Filled.List,
                                    "ИИ" to Icons.Default.Settings, "Подключение" to Icons.Default.Info)
                                tabs.forEachIndexed { index, (label, icon) ->
                                    NavigationBarItem(selected = tab == index, onClick = { tab = index },
                                        icon = { Icon(icon, null, Modifier.size(21.dp)) },
                                        label = { Text(label, fontSize = 10.sp) },
                                        colors = NavigationBarItemDefaults.colors(indicatorColor = Lavender.copy(alpha = .18f),
                                            selectedIconColor = Lavender, selectedTextColor = White, unselectedTextColor = Muted))
                                }
                            }
                        }) { inset ->
                        Box(Modifier.fillMaxSize().padding(inset)) {
                            when (tab) {
                                0 -> Dashboard(model, pref, sim, live, ready, source,
                                    onSource = { source = it },
                                    onSettings = { tab = 3 },
                                    onStart = { initial ->
                                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        if (source) {
                                            val cfg = model.configuration()
                                            if (cfg != null && !sim.active) {
                                                if (!live.capturing || model.calibration.value.missing.isNotEmpty() ||
                                                    model.calibration.value.fighter != cfg.fighter || !PilotGestures.enabled()) {
                                                    tab = 3
                                                    model.message.value = "Для запуска закончи подключение и калибровку"
                                                } else if (launchGame()) LiveBus.arm(cfg)
                                            }
                                        } else {
                                            requestNotifications()
                                            model.startSimulator(initial)
                                        }
                                    },
                                    onPause = { if (source) ProjectionService.command(this@MainActivity, ProjectionService.PAUSE)
                                        else model.pauseSimulator() },
                                    onStop = { if (source) ProjectionService.command(this@MainActivity, ProjectionService.STOP)
                                        else model.stopSimulator() })
                                1 -> AnalyticsScreen(report)
                                2 -> EngineSettings(model, pref.options, !sim.active && !live.active)
                                else -> {
                                    val revision = permissionRevision
                                    ConnectionScreen(model, pref, live,
                                        gesturesEnabled = remember(revision, live.capturing) { PilotGestures.enabled() },
                                        overlayEnabled = remember(revision) { Settings.canDrawOverlays(this@MainActivity) },
                                        hasFile = remember(fileRevision) { importedFile != null },
                                        onAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                                        onOverlayPermission = { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:$packageName"))) },
                                        onCapture = {
                                            if (live.capturing) ProjectionService.command(this@MainActivity, ProjectionService.STOP)
                                            else {
                                                if (needsNotifications()) {
                                                    requestCaptureAfterNotifications = true
                                                    requestNotifications()
                                                } else projection.launch(ProjectionService.consentIntent(this@MainActivity))
                                            }
                                        },
                                        onOpenGame = { launchGame() },
                                        onSnapshot = {
                                            if (launchGame()) ProjectionService.command(this@MainActivity, ProjectionService.SNAPSHOT)
                                        },
                                        onOverlay = { ProjectionService.command(this@MainActivity, ProjectionService.OVERLAY) },
                                        onImport = { file.launch(arrayOf("image/*", "video/*")) },
                                        onSample = { fraction -> importedFile?.let { model.import(it, fraction) } })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        permissionRevision++
    }

    private fun needsNotifications() = Build.VERSION.SDK_INT >= 33 &&
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun requestNotifications() {
        if (needsNotifications()) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun launchGame(): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(PilotGestures.GAME_PACKAGE)
        if (intent == null) {
            model.message.value = "Brawl Stars не найден на этом устройстве"
            return false
        }
        return runCatching { startActivity(intent) }.isSuccess
    }
}
