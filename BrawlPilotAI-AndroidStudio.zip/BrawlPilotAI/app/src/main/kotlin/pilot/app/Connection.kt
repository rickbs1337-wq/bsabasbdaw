package pilot.app

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pilot.data.Preferences
import pilot.domain.Area
import pilot.domain.Vec
import pilot.screen.LiveStatus
import pilot.vision.Mark
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun ConnectionScreen(
    model: PilotModel, pref: Preferences, live: LiveStatus, gesturesEnabled: Boolean, overlayEnabled: Boolean,
    hasFile: Boolean, onAccessibility: () -> Unit, onOverlayPermission: () -> Unit, onCapture: () -> Unit,
    onOpenGame: () -> Unit, onSnapshot: () -> Unit, onOverlay: () -> Unit, onImport: () -> Unit, onSample: (Float) -> Unit
) {
    val calibration by model.calibration.collectAsStateWithLifecycle()
    val snapshot by model.snapshot.collectAsStateWithLifecycle()
    val imported by model.imported.collectAsStateWithLifecycle()
    val observation by model.offline.collectAsStateWithLifecycle()
    var useImport by rememberSaveable { mutableStateOf(false) }
    val frame = if (useImport) imported ?: snapshot else snapshot ?: imported
    var chosen by rememberSaveable { mutableStateOf(Mark.LOBBY.name) }
    val mark = Mark.valueOf(chosen)
    var selectMark by rememberSaveable { mutableStateOf(false) }
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    var region by remember(frame, mark) { mutableStateOf<Area?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassPanel {
            Micro("ANDROID · LIVE", Cyan)
            Heading("Подключение к игре")
            Hint("Экспериментальный режим «Столкновение». Для запуска выбери бойца и режим в самой игре.")
            PermissionRow("Жесты Android", gesturesEnabled,
                if (gesturesEnabled) "Настройки" else "Включить", onAccessibility)
            PermissionRow("Плавающая панель", overlayEnabled,
                if (overlayEnabled) "Настройки" else "Разрешить", onOverlayPermission)
            PermissionRow("Захват экрана", live.capturing,
                if (live.capturing) "Остановить" else "Включить", onCapture)
            Hint(live.message, if (live.active) Mint else Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Открыть игру", onOpenGame, Modifier.weight(1f))
                GlassButton("Панель в игре", onOverlay, Modifier.weight(1f), enabled = overlayEnabled && live.capturing)
            }
        }
        GlassPanel {
            val count = Mark.entries.count { it.required }
            val progress = count - calibration.missing.size
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Heading("Калибровка")
                StatusPill("$progress / $count", progress == count)
            }
            Hint("Боец · ${calibration.fighter.ifEmpty { pref.fighter }}")
            if (calibration.fighter.isNotEmpty() && calibration.fighter != pref.fighter)
                Hint("Сбрось калибровку, чтобы записать образцы для ${pref.fighter}.", Rose)
            Hint("Сними лобби, бой и оба экрана результатов. На каждом кадре выбери элемент и обведи его пальцем.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Снимок игры", { useImport = false; onSnapshot() }, Modifier.weight(1f),
                    enabled = live.capturing && gesturesEnabled && !live.active)
                GlassButton("Открыть файл", { useImport = true; onImport() }, Modifier.weight(1f), enabled = !live.active)
            }
            if (snapshot != null && imported != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Снимок", { useImport = false }, Modifier.weight(1f), primary = !useImport)
                GlassButton("Файл", { useImport = true }, Modifier.weight(1f), primary = useImport)
            }
            if (frame != null && !live.active) {
                if (useImport && hasFile) Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    for ((label, value) in listOf("0%" to 0f, "25%" to .25f, "50%" to .5f, "75%" to .75f)) {
                        GlassButton(label, { onSample(value) }, Modifier.weight(1f))
                    }
                }
                GlassButton("${mark.title}  ▾", { selectMark = true }, Modifier.fillMaxWidth())
                Hint(mark.hint)
                FrameEditor(frame, region, { region = it }, observation?.world, pref.options.debugBoxes)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Сохранить область", { region?.let { model.mark(mark, frame, it) } },
                        Modifier.weight(1f), primary = true, enabled = region != null)
                    GlassButton("Анализ кадра", { model.inspect(frame) }, Modifier.weight(1f),
                        enabled = calibration.marks.isNotEmpty())
                }
                observation?.let {
                    Hint("Лобби ${yes(it.lobby)} · Бой ${yes(it.hud)} · Врагов ${it.world?.enemies?.size ?: 0} · Выход ${yes(it.exit)}")
                    if (pref.options.debugBoxes) for (detection in it.detections.take(24)) {
                        val center = detection.area.center
                        Micro("${detection.kind.title} · ${(detection.confidence * 100).roundToInt()}% · x=${(center.x * frame.width).roundToInt()} y=${(center.y * frame.height).roundToInt()}", Cyan)
                    }
                }
            }
            if (calibration.marks.isNotEmpty()) GlassButton("Сбросить калибровку", { confirmReset = true },
                Modifier.fillMaxWidth(), enabled = !live.active, tone = Rose)
        }
        if (live.logs.isNotEmpty()) GlassPanel {
            Heading("Журнал сессии")
            live.logs.takeLast(15).asReversed().forEach { Hint(it) }
        }
    }
    if (selectMark) AlertDialog({ selectMark = false }, title = { Heading("Что выделить") }, text = {
        Column(Modifier.heightIn(max = 395.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Mark.entries.forEach { item ->
                GlassButton(item.title + when {
                    item in calibration.marks -> " ✓"
                    !item.required -> " · доп."
                    else -> ""
                }, { chosen = item.name; selectMark = false }, Modifier.fillMaxWidth(), primary = mark == item)
            }
        }
    }, confirmButton = { TextButton({ selectMark = false }) { Text("Закрыть") } })
    if (confirmReset) AlertDialog({ confirmReset = false }, title = { Heading("Сбросить калибровку?") },
        text = { Hint("Сохранённые области и образцы придётся отметить заново.") },
        confirmButton = { TextButton({ model.resetCalibration(); confirmReset = false }) { Text("Сбросить") } },
        dismissButton = { TextButton({ confirmReset = false }) { Text("Отмена") } })
}

private fun yes(value: Boolean) = if (value) "✓" else "—"

@Composable
private fun PermissionRow(label: String, enabled: Boolean, button: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f)) {
            Text(label, color = White, fontSize = 14.sp)
            Micro(if (enabled) "АКТИВНО" else "ВЫКЛ.", if (enabled) Mint else Muted)
        }
        GlassButton(button, onClick)
    }
}

@Composable
private fun FrameEditor(frame: Bitmap, region: Area?, setRegion: (Area?) -> Unit, world: pilot.domain.World?, boxes: Boolean) {
    val image = remember(frame) { frame.asImageBitmap() }
    val writeRegion by rememberUpdatedState(setRegion)
    val shape = RoundedCornerShape(13.dp)
    Box(Modifier.fillMaxWidth().aspectRatio(frame.width.toFloat() / frame.height)
        .clip(shape).background(Night).border(1.dp, Line, shape)
        .pointerInput(frame) {
            fun normalized(p: Offset) = Vec(p.x / size.width, p.y / size.height).clamp()
            var start = Vec.ZERO
            var end = Vec.ZERO
            detectDragGestures(onDragStart = {
                start = normalized(it)
                end = start
                writeRegion(null)
            }) { change, _ ->
                change.consume()
                end = normalized(change.position)
                writeRegion(Area(min(start.x, end.x), min(start.y, end.y), max(start.x, end.x), max(start.y, end.y)))
            }
        }, contentAlignment = Alignment.Center) {
        Image(image, "Кадр для калибровки", Modifier.matchParentSize(), contentScale = ContentScale.FillBounds)
        Canvas(Modifier.matchParentSize()) {
            region?.let {
                val offset = Offset(it.left * size.width, it.top * size.height)
                val bounds = Size((it.right - it.left) * size.width, (it.bottom - it.top) * size.height)
                drawRect(Lavender.copy(alpha = .20f), offset, bounds)
                drawRect(Cyan, offset, bounds, style = Stroke(2.dp.toPx()))
            }
            if (boxes && world != null) {
                world.walls.forEach {
                    drawRect(Lavender, Offset(it.left * size.width, it.top * size.height),
                        Size((it.right - it.left) * size.width, (it.bottom - it.top) * size.height),
                        style = Stroke(1.dp.toPx()))
                }
                fun actor(point: Vec, color: androidx.compose.ui.graphics.Color) {
                    val center = Offset(point.x * size.width, point.y * size.height)
                    drawCircle(color, 7.dp.toPx(), center, style = Stroke(2.dp.toPx()))
                }
                world.self?.let { actor(it.point, Cyan) }
                world.enemies.forEach { actor(it.point, Rose) }
                world.allies.forEach { actor(it.point, Mint) }
            }
        }
    }
}
