package pilot.domain

import kotlin.math.hypot

data class Vec(val x: Float, val y: Float) {
    operator fun plus(other: Vec) = Vec(x + other.x, y + other.y)
    operator fun minus(other: Vec) = Vec(x - other.x, y - other.y)
    operator fun times(scale: Float) = Vec(x * scale, y * scale)
    fun length(): Float = hypot(x, y)
    fun distance(other: Vec) = (this - other).length()
    fun direction(): Vec = if (length() < 0.0001f) ZERO else this * (1f / length())
    fun clamp() = Vec(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f))

    companion object { val ZERO = Vec(0f, 0f) }
}

data class Area(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val center get() = Vec((left + right) / 2, (top + bottom) / 2)
    fun contains(v: Vec, margin: Float = 0f) =
        v.x >= left - margin && v.x <= right + margin &&
            v.y >= top - margin && v.y <= bottom + margin
}

data class Actor(
    val point: Vec,
    val confidence: Float,
    val health: Float? = null,
    val velocity: Vec = Vec.ZERO
)

enum class Mode(val label: String) {
    SURVIVAL("Столкновение"), BALL("Броулбол"), GEMS("Захват кристаллов")
}

enum class PlayStyle(val label: String, val retreat: Float) {
    AGGRESSIVE("Агрессивно", .23f), BALANCED("Сбалансированно", .38f), SAFE("Осторожно", .56f)
}

data class Profile(
    val name: String,
    val range: Float,
    val preferred: Float,
    val speed: Float,
    val damage: Float,
    val cooldown: Float,
    val superMinEnemies: Int
)

object Profiles {
    val available = listOf(
        Profile("Шелли", .28f, .17f, .23f, .25f, .62f, 2),
        Profile("Кольт", .40f, .31f, .20f, .21f, .48f, 2),
        Profile("Мортис", .16f, .10f, .29f, .29f, .58f, 1),
        Profile("Леон", .32f, .21f, .27f, .22f, .46f, 2)
    )
    private val aliases = mapOf("Shelly" to "Шелли", "Colt" to "Кольт", "Mortis" to "Мортис", "Leon" to "Леон")
    fun find(name: String) = available.firstOrNull { it.name.equals(aliases[name] ?: name, true) }
}

data class Options(
    val style: PlayStyle = PlayStyle.BALANCED,
    val fps: Int = 5,
    val seconds: Int = 600,
    val matchLimit: Int = 25,
    val confidence: Float = .75f,
    val debugBoxes: Boolean = false,
    val diagnostics: Boolean = true,
    val autoPause: Boolean = true
)

data class Configuration(val fighter: String, val profile: Profile, val target: Int, val mode: Mode, val options: Options)
enum class Source { SIMULATOR, GAME }
enum class Result { WIN, LOSS, DRAW, UNKNOWN }
enum class Phase {
    IDLE, HOME, BRAWLER_SELECTION, MODE_SELECTION, MATCHMAKING, LOADING,
    IN_MATCH, RESULTS, TROPHY_CHECK, NEXT_MATCH, PAUSED, DONE
}
data class Battle(val trophies: Int, val result: Result, val time: Long)
data class Report(
    val id: String, val configuration: Configuration, val source: Source,
    val initial: Int, val started: Long, val battles: List<Battle> = emptyList()
) {
    val current get() = battles.lastOrNull()?.trophies ?: initial
}

data class World(
    val self: Actor?,
    val enemies: List<Actor>,
    val allies: List<Actor> = emptyList(),
    val walls: List<Area> = emptyList(),
    val danger: List<Area> = emptyList(),
    val ball: Vec? = null,
    val goal: Vec? = null,
    val gems: Vec? = null,
    val superReady: Boolean = false,
    val confidence: Float = 1f,
    val cameraOffset: Vec = Vec.ZERO
)

data class Decision(
    val movement: Vec = Vec.ZERO,
    val aim: Vec? = null,
    val superAttack: Boolean = false,
    val reason: String = "Ожидание"
)
