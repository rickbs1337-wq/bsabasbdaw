package pilot.engine

import pilot.domain.*
import kotlin.math.min
import kotlin.random.Random

data class ArenaFrame(
    val world: World, val decision: Decision = Decision(),
    val time: Float = 0f, val objectives: Int = 0, val hit: Vec? = null, val result: Result? = null
)

class Arena(private val configuration: Configuration, round: Int) {
    private data class UnitState(var point: Vec, var health: Float, var cooldown: Float, var velocity: Vec = Vec.ZERO)
    private val random = Random(round * 199 + configuration.mode.ordinal)
    private val profile = configuration.profile
    private val pilot = Pilot()
    private val walls = listOf(Area(.22f,.29f,.38f,.43f), Area(.60f,.59f,.74f,.75f),
        Area(.48f,.19f,.62f,.26f), Area(.35f,.66f,.48f,.74f))
    private val self = UnitState(Vec(.16f, .78f), 1f, 0f)
    private val enemies = MutableList(3) { index ->
        UnitState(Vec(.47f + index * .15f, .21f + index * .14f), .62f, 1.8f + random.nextFloat())
    }
    private val friendly = Actor(Vec(.17f,.54f), 1f, 1f)
    private var gem = Vec(.52f,.48f)
    private var ball = Vec(.54f,.40f)
    private val goal = Vec(.91f,.13f)
    private var time = 0f
    private var charge = 0
    private var objectives = 0
    private var result: Result? = null
    private var hit: Vec? = null
    private var decision = Decision()
    private var damagedAt = -10f

    fun frame() = ArenaFrame(world(), decision, time, objectives, hit, result)

    private fun world(): World {
        val danger = if (configuration.mode == Mode.SURVIVAL && time > 9) {
            val edge = min(.22f, (time - 9) * .013f)
            listOf(Area(0f,0f,edge,1f), Area(1f-edge,0f,1f,1f), Area(0f,0f,1f,edge), Area(0f,1f-edge,1f,1f))
        } else emptyList()
        return World(Actor(self.point, 1f, self.health), enemies.filter { it.health > 0 }.map {
            Actor(it.point, 1f, it.health, it.velocity)
        }, if (configuration.mode == Mode.SURVIVAL) emptyList() else listOf(friendly), walls, danger,
            ball.takeIf { configuration.mode == Mode.BALL }, goal.takeIf { configuration.mode == Mode.BALL },
            gem.takeIf { configuration.mode == Mode.GEMS }, charge >= 4)
    }

    fun tick(dt: Float): ArenaFrame {
        if (result != null) return frame()
        time += dt
        hit = null
        val world = world()
        decision = pilot.decide(world, profile, configuration.mode, configuration.options, dt)
        self.point = move(self.point, decision.movement * (profile.speed * dt))
        self.cooldown -= dt
        val aim = decision.aim
        if (aim != null && self.cooldown <= 0) {
            val victim = enemies.filter { it.health > 0 }.minByOrNull { it.point.distance(aim) }
            if (victim != null && victim.point.distance(aim) < .16f &&
                clearLine(self.point, victim.point, walls) && self.point.distance(victim.point) <= profile.range + .015f) {
                hit = victim.point
                self.cooldown = profile.cooldown
                victim.health -= profile.damage
                if (decision.superAttack) {
                    enemies.filter { self.point.distance(it.point) <= profile.range * 1.20f &&
                        clearLine(self.point, it.point, walls) }.forEach { it.health -= .40f }
                    charge = 0
                } else {
                    charge++
                }
            }
        }
        for (unit in enemies.filter { it.health > 0 }) {
            val distance = unit.point.distance(self.point)
            val movement = if (distance > .19f) (self.point - unit.point).direction() else Vec.ZERO
            val alternate = Vec(-movement.y, movement.x)
            val next = move(unit.point, movement * (.075f * dt))
            val position = if (next == unit.point) move(unit.point, alternate * (.057f * dt)) else next
            unit.velocity = (position - unit.point) * (1f / dt)
            unit.point = position
            unit.cooldown -= dt
            if (unit.cooldown <= 0 && distance < .23f && clearLine(unit.point, self.point, walls)) {
                unit.cooldown = 1.15f + random.nextFloat() * .58f
                self.health -= .093f
                damagedAt = time
            }
        }
        if (world.danger.any { it.contains(self.point) }) {
            self.health -= dt * .11f
            damagedAt = time
        }
        if (time - damagedAt > 2.5f) self.health = min(1f, self.health + dt * .075f)
        when (configuration.mode) {
            Mode.BALL -> if (ball.distance(self.point) < .075f) {
                ball = self.point
                if (ball.distance(goal) < .10f) objectives = 1
            }
            Mode.GEMS -> if (gem.distance(self.point) < .065f) {
                objectives++
                gem = listOf(Vec(.68f,.36f), Vec(.31f,.57f), Vec(.55f,.40f), Vec(.80f,.51f))[objectives % 4]
            }
            Mode.SURVIVAL -> objectives = enemies.count { it.health <= 0 }
        }
        val won = when (configuration.mode) {
            Mode.BALL -> objectives >= 1
            Mode.GEMS -> objectives >= 4
            Mode.SURVIVAL -> objectives >= enemies.size
        }
        result = when {
            self.health <= 0 -> Result.LOSS
            won -> Result.WIN
            time >= 34f -> Result.LOSS
            else -> null
        }
        return frame()
    }

    private fun move(from: Vec, delta: Vec): Vec {
        val point = from + delta
        val next = Vec(point.x.coerceIn(.045f,.955f), point.y.coerceIn(.045f,.955f))
        return if (walls.any { it.contains(next, .017f) }) from else next
    }
}
