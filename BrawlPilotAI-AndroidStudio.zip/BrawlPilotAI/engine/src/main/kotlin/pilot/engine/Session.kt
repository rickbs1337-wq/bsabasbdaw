package pilot.engine

import pilot.domain.*
import java.util.UUID

class Session(
    configuration: Configuration,
    source: Source,
    initial: Int,
    now: Long = System.currentTimeMillis()
) {
    var report = Report(UUID.randomUUID().toString(), configuration, source, initial, now)
        private set
    var phase = Phase.HOME
        private set
    var message = ""
        private set
    private var suspended = Phase.HOME
    private var lastRecordedRound = 0
    var round = 0
        private set

    init {
        require(initial >= 0 && configuration.target > 0)
        require(configuration.options.matchLimit > 0 && configuration.options.seconds > 0)
        if (initial >= configuration.target) stop("Цель уже достигнута")
    }

    fun step(next: Phase): Boolean {
        val valid = when (phase) {
            Phase.HOME -> next == Phase.BRAWLER_SELECTION
            Phase.BRAWLER_SELECTION -> next == Phase.MODE_SELECTION
            Phase.MODE_SELECTION, Phase.NEXT_MATCH -> next == Phase.MATCHMAKING
            Phase.MATCHMAKING -> next == Phase.LOADING
            Phase.LOADING -> next == Phase.IN_MATCH
            Phase.IN_MATCH -> next == Phase.RESULTS
            Phase.RESULTS -> next == Phase.TROPHY_CHECK
            else -> false
        }
        if (!valid) return false
        phase = next
        if (phase == Phase.IN_MATCH) round++
        return true
    }

    fun timeCheck(now: Long): Boolean {
        if (phase != Phase.DONE && now - report.started >= report.configuration.options.seconds * 1000L) {
            stop("Достигнут лимит времени")
        }
        return phase != Phase.DONE
    }

    fun record(trophies: Int?, result: Result, now: Long): Boolean {
        if (phase != Phase.TROPHY_CHECK || round <= lastRecordedRound) return false
        if (trophies == null || trophies < 0) {
            pause("Кубки не подтверждены")
            return false
        }
        lastRecordedRound = round
        report = report.copy(battles = report.battles + Battle(trophies, result, now))
        when {
            trophies >= report.configuration.target -> stop("Цель достигнута")
            report.battles.size >= report.configuration.options.matchLimit -> stop("Достигнут лимит матчей")
            timeCheck(now) -> phase = Phase.NEXT_MATCH
        }
        return true
    }

    fun pause(reason: String) {
        if (phase == Phase.DONE) return
        if (phase != Phase.PAUSED) suspended = phase
        phase = Phase.PAUSED
        message = reason
    }

    fun resume(now: Long): Boolean {
        if (phase != Phase.PAUSED || !timeCheck(now)) return false
        phase = suspended
        message = ""
        return true
    }

    fun stop(reason: String) {
        if (phase == Phase.DONE) return
        phase = Phase.DONE
        message = reason
    }
}
