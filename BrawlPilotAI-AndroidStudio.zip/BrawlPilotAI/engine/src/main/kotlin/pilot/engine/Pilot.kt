package pilot.engine

import pilot.domain.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class Pilot(private val navigation: Navigation = Navigation()) {
    private var origin: Vec? = null
    private var blockedAt: Vec? = null
    private var movementSeconds = 0f
    private var recovery = 0f
    private var priorMovement = Vec.ZERO

    fun decide(world: World, profile: Profile, mode: Mode, options: Options, dt: Float): Decision {
        val self = world.self ?: return Decision(reason = "Боец вне кадра")
        if (world.confidence < options.confidence || self.confidence < options.confidence) {
            priorMovement = Vec.ZERO
            movementSeconds = 0f
            return Decision(reason = "Низкая уверенность")
        }
        val here = self.point
        val observedPosition = here + world.cameraOffset
        if (origin == null || observedPosition.distance(origin!!) > .04f || priorMovement == Vec.ZERO) {
            origin = observedPosition
            movementSeconds = 0f
        } else {
            movementSeconds += dt
        }
        recovery = (recovery - dt).coerceAtLeast(0f)
        if (movementSeconds > 1.25f) {
            blockedAt = (here + priorMovement * .09f).clamp()
            recovery = 1.2f
            movementSeconds = 0f
        }
        val enemies = world.enemies.filter { it.confidence >= options.confidence }
        val target = enemies.minByOrNull {
            here.distance(it.point) + (if (clearLine(here, it.point, world.walls)) 0f else .24f) +
                ((it.health ?: .65f) * .08f)
        }
        val closestAlly = world.allies.filter { it.confidence >= options.confidence }.minByOrNull { here.distance(it.point) }
        val distance = target?.let { here.distance(it.point) } ?: Float.POSITIVE_INFINITY
        val retreat = (self.health ?: 1f) < options.style.retreat && distance < profile.range + .09f
        val ball = world.ball
        val gems = world.gems
        val desired = when {
            retreat || world.danger.any { it.contains(here) } ->
                safest(here, enemies, world, closestAlly?.point)
            mode == Mode.BALL && ball != null ->
                if (here.distance(ball) < .065f) world.goal ?: ball else ball
            mode == Mode.GEMS && gems != null && distance > .14f -> gems
            target == null -> listOfNotNull(world.gems, world.ball).firstOrNull() ?: here
            !clearLine(here, target.point, world.walls) -> target.point
            distance > profile.preferred * 1.20f -> target.point
            distance < profile.preferred * .62f && profile.range >= .3f ->
                here + (here - target.point).direction() * .15f
            else -> here
        }
        val going = if (here.distance(desired) < .016f) Vec.ZERO
            else navigation.direction(here, desired, world.walls, world.danger, blockedAt.takeIf { recovery > 0f })
        priorMovement = going
        val predicted = target?.let { (it.point + it.velocity * .18f).clamp() }
        val aim = predicted?.takeIf {
            !retreat && here.distance(it) <= profile.range && clearLine(here, it, world.walls, .005f)
        }
        val superAttack = aim != null && world.superReady && enemies.count {
            here.distance(it.point) < profile.range * 1.20f && clearLine(here, it.point, world.walls)
        } >= profile.superMinEnemies
        val reason = when {
            recovery > 0 -> "Перестраиваю маршрут"
            retreat -> "Отступаю"
            superAttack -> "Супер"
            aim != null -> "Атакую"
            going != Vec.ZERO -> "Занимаю позицию"
            else -> "Жду цель"
        }
        return Decision(going, aim, superAttack, reason)
    }

    private fun safest(here: Vec, enemies: List<Actor>, world: World, ally: Vec?): Vec {
        return (0 until 16).map { index ->
            val angle = index * PI / 8
            (here + Vec(cos(angle).toFloat(), sin(angle).toFloat()) * .23f).clamp()
        }.filter { candidate ->
            candidate.x in .04f.. .96f && candidate.y in .04f.. .96f &&
                world.walls.none { it.contains(candidate, .015f) }
        }.maxByOrNull { candidate ->
            val danger = if (world.danger.any { it.contains(candidate, .01f) }) 1f else 0f
            val cover = if (clearLine(here, candidate, world.walls)) .10f else 0f
            val support = ally?.let { (1f - candidate.distance(it)) * .06f } ?: 0f
            (enemies.minOfOrNull { candidate.distance(it.point) } ?: .4f) + cover + support - danger
        } ?: Vec(.5f, .5f)
    }
}
