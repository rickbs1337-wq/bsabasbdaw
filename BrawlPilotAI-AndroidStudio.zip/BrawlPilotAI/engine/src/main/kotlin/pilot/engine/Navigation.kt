package pilot.engine

import java.util.PriorityQueue
import pilot.domain.Area
import pilot.domain.Vec
import kotlin.math.abs
import kotlin.math.floor

fun clearLine(from: Vec, to: Vec, walls: List<Area>, margin: Float = 0f): Boolean {
    val steps = (from.distance(to) / .012f).toInt().coerceAtLeast(1)
    return (0..steps).none { index ->
        val p = from + (to - from) * (index.toFloat() / steps)
        walls.any { it.contains(p, margin) }
    }
}

class Navigation(private val size: Int = 22) {
    private data class QueueItem(val cell: Int, val score: Float)

    fun direction(from: Vec, to: Vec, walls: List<Area>, danger: List<Area>, avoid: Vec?): Vec {
        val end = to.clamp()
        if (avoid == null && clearLine(from, end, walls + danger, .012f)) return (end - from).direction()
        val count = size * size
        fun center(cell: Int) = Vec((cell % size + .5f) / size, (cell / size + .5f) / size)
        fun index(p: Vec): Int {
            val x = floor(p.x * size).toInt().coerceIn(0, size - 1)
            val y = floor(p.y * size).toInt().coerceIn(0, size - 1)
            return y * size + x
        }
        val start = index(from)
        val allowed = BooleanArray(count) { cell -> walls.none { it.contains(center(cell), .014f) } }
        allowed[start] = true
        val goal = (0 until count).filter { allowed[it] }.minByOrNull { center(it).distance(end) } ?: return Vec.ZERO
        val costs = FloatArray(count) { Float.POSITIVE_INFINITY }
        val parent = IntArray(count) { -1 }
        val closed = BooleanArray(count)
        val open = PriorityQueue<QueueItem>(compareBy { it.score })
        costs[start] = 0f
        open.add(QueueItem(start, 0f))
        var closest = start
        while (open.isNotEmpty()) {
            val current = open.remove().cell
            if (closed[current]) continue
            closed[current] = true
            if (center(current).distance(end) < center(closest).distance(end)) closest = current
            if (current == goal) break
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val x = current % size + dx
                val y = current / size + dy
                if (x !in 0 until size || y !in 0 until size) continue
                val next = y * size + x
                if (closed[next] || !allowed[next]) continue
                if (dx != 0 && dy != 0 && (!allowed[current + dx] || !allowed[current + dy * size])) continue
                val p = center(next)
                if (!clearLine(if (current == start) from else center(current), p, walls, .004f)) continue
                val penalty = (if (danger.any { it.contains(p) }) 5f else 0f) +
                    (if (avoid != null && p.distance(avoid) < .13f) 7f else 0f)
                val cost = costs[current] + (if (abs(dx) + abs(dy) == 2) 1.414f else 1f) + penalty
                if (cost >= costs[next]) continue
                costs[next] = cost
                parent[next] = current
                open.add(QueueItem(next, cost + p.distance(center(goal)) * size))
            }
        }
        var step = if (closed[goal]) goal else closest
        if (step == start) return Vec.ZERO
        while (parent[step] != start) {
            step = parent[step]
            if (step < 0) return Vec.ZERO
        }
        return (center(step) - from).direction()
    }
}
