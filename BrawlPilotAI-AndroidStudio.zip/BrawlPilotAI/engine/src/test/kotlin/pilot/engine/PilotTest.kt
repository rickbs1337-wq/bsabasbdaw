package pilot.engine

import org.junit.Assert.*
import org.junit.Test
import pilot.domain.*

class PilotTest {
    private val profile = Profiles.find("Шелли")!!
    private fun config(mode: Mode = Mode.SURVIVAL, target: Int = 500, limit: Int = 6) =
        Configuration(profile.name, profile, target, mode, Options(matchLimit = limit))

    @Test fun routeFindsPassageAroundWall() {
        val from = Vec(.22f, .48f)
        val to = Vec(.80f, .48f)
        val wall = Area(.40f,.22f,.59f,.72f)
        val navigation = Navigation()
        var position = from
        repeat(120) {
            if (position.distance(to) > .028f) {
                val movement = navigation.direction(position, to, listOf(wall), emptyList(), null) * .015f
                position += movement
                assertFalse(wall.contains(position))
            }
        }
        assertTrue("Position: $position", position.distance(to) < .04f)
    }

    @Test fun unsafeRecognitionProducesNoInput() {
        val observation = World(Actor(Vec(.3f,.3f), .55f), listOf(Actor(Vec(.7f,.7f), 1f)), confidence = .55f)
        val decision = Pilot().decide(observation, profile, Mode.SURVIVAL, Options(confidence = .8f), .2f)
        assertEquals(Vec.ZERO, decision.movement)
        assertNull(decision.aim)
        assertFalse(decision.superAttack)
    }

    @Test fun weakHealthTriggersRetreat() {
        val observation = World(Actor(Vec(.5f,.5f), 1f, .4f), listOf(Actor(Vec(.65f,.50f), 1f)))
        val decision = Pilot().decide(observation, profile, Mode.SURVIVAL, Options(style = PlayStyle.SAFE), .2f)
        assertTrue(decision.movement.x < 0f)
        assertNull(decision.aim)
    }

    @Test fun attackRespectsWalls() {
        val world = World(Actor(Vec(.40f,.50f), 1f), listOf(Actor(Vec(.52f,.50f), 1f)),
            walls = listOf(Area(.43f,.36f,.49f,.66f)))
        val decision = Pilot().decide(world, profile, Mode.SURVIVAL, Options(), .2f)
        assertNull(decision.aim)
        assertTrue(decision.movement.length() > 0f)
    }

    @Test fun stuckMotionTriggersRecovery() {
        val world = World(Actor(Vec(.28f,.50f), 1f), listOf(Actor(Vec(.82f,.5f), 1f)))
        val pilot = Pilot()
        repeat(8) { pilot.decide(world, profile, Mode.SURVIVAL, Options(), .2f) }
        assertEquals("Перестраиваю маршрут", pilot.decide(world, profile, Mode.SURVIVAL, Options(), .2f).reason)
    }

    @Test fun skipsUnconfirmedTrophiesAndStopsAtTarget() {
        val session = Session(config(), Source.GAME, 480, 0)
        assertFalse(session.step(Phase.IN_MATCH))
        toTrophy(session)
        assertFalse(session.record(null, Result.WIN, 20))
        assertEquals(Phase.PAUSED, session.phase)
        assertEquals(480, session.report.current)
        assertTrue(session.resume(30))
        assertTrue(session.record(503, Result.WIN, 40))
        assertEquals(Phase.DONE, session.phase)
        assertFalse(session.record(520, Result.WIN, 50))
        assertEquals(503, session.report.current)
        assertEquals(1, session.report.battles.size)
    }

    @Test fun respectsRoundAndTimeLimits() {
        val matchLimited = Session(config(limit = 1), Source.SIMULATOR, 400, 0)
        toTrophy(matchLimited)
        assertTrue(matchLimited.record(396, Result.LOSS, 50))
        assertEquals(Phase.DONE, matchLimited.phase)
        assertEquals("Достигнут лимит матчей", matchLimited.message)
        val timeLimited = Session(config(), Source.SIMULATOR, 400, 0)
        timeLimited.pause("off")
        assertFalse(timeLimited.resume(600_000))
        assertEquals(Phase.DONE, timeLimited.phase)
    }

    @Test fun arenaExecutesAllModesAndCompletesRounds() {
        for (mode in Mode.entries) {
            val arena = Arena(config(mode), 1)
            val initial = arena.frame().world.self!!.point
            var moved = false
            var attack = false
            repeat(400) {
                val frame = arena.tick(.1f)
                moved = moved || initial.distance(frame.world.self!!.point) > .12f
                attack = attack || frame.hit != null
            }
            assertTrue("$mode did not travel far enough", moved)
            assertTrue("$mode ended with no outcome", arena.frame().result != null)
            if (mode == Mode.SURVIVAL) assertTrue("No attack", attack)
        }
    }

    private fun toTrophy(session: Session) {
        listOf(Phase.BRAWLER_SELECTION, Phase.MODE_SELECTION, Phase.MATCHMAKING, Phase.LOADING,
            Phase.IN_MATCH, Phase.RESULTS, Phase.TROPHY_CHECK).forEach { assertTrue(session.step(it)) }
    }
}
