package pilot.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import pilot.domain.*
import java.net.URL
import javax.net.ssl.HttpsURLConnection

private val Context.prefs by preferencesDataStore("brawl-pilot")

data class Preferences(
    val fighter: String = "Шелли",
    val goal: Int = 500,
    val mode: Mode = Mode.SURVIVAL,
    val favorites: Set<String> = emptySet(),
    val options: Options = Options()
)

class Settings(private val context: Context) {
    val values = context.prefs.data.map { p ->
        Preferences(p[fighter] ?: "Шелли", p[goal] ?: 500,
            Mode.entries.firstOrNull { it.name == p[mode] } ?: Mode.SURVIVAL,
            p[favorites] ?: emptySet(),
            Options(PlayStyle.entries.firstOrNull { it.name == p[style] } ?: PlayStyle.BALANCED,
                p[fps] ?: 5, p[seconds] ?: 600, p[limit] ?: 25, p[confidence] ?: .75f,
                p[boxes] ?: false, p[logs] ?: true, p[pause] ?: true))
    }

    suspend fun save(value: Preferences) {
        context.prefs.edit { p ->
            p[fighter] = value.fighter
            p[goal] = value.goal
            p[mode] = value.mode.name
            p[favorites] = value.favorites
            p[style] = value.options.style.name
            p[fps] = value.options.fps
            p[seconds] = value.options.seconds
            p[limit] = value.options.matchLimit
            p[confidence] = value.options.confidence
            p[boxes] = value.options.debugBoxes
            p[logs] = value.options.diagnostics
            p[pause] = value.options.autoPause
        }
    }

    private companion object {
        val fighter = stringPreferencesKey("fighter")
        val goal = intPreferencesKey("goal")
        val mode = stringPreferencesKey("mode")
        val favorites = stringSetPreferencesKey("favorites")
        val style = stringPreferencesKey("style")
        val fps = intPreferencesKey("fps")
        val seconds = intPreferencesKey("seconds")
        val limit = intPreferencesKey("match_limit")
        val confidence = floatPreferencesKey("confidence")
        val boxes = booleanPreferencesKey("debug_boxes")
        val logs = booleanPreferencesKey("logs")
        val pause = booleanPreferencesKey("auto_pause")
    }
}

@Entity(tableName = "sessions")
data class SavedReport(
    @PrimaryKey val id: String, val source: String, val fighter: String, val mode: String,
    val initial: Int, val current: Int, val goal: Int, val started: Long,
    val updated: Long, val reason: String, val roundsJson: String
) {
    fun rounds(): List<Battle> {
        val json = JSONArray(roundsJson)
        return List(json.length()) { index ->
            val row = json.getJSONObject(index)
            Battle(row.getInt("trophies"), Result.valueOf(row.getString("result")), row.getLong("time"))
        }
    }
}

@Dao
interface ReportsDao {
    @Query("SELECT * FROM sessions ORDER BY started DESC LIMIT 50")
    fun observe(): Flow<List<SavedReport>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(report: SavedReport)
}

@Database(entities = [SavedReport::class], version = 1, exportSchema = false)
abstract class PilotDb : RoomDatabase() {
    abstract fun reports(): ReportsDao
}

class History(context: Context) {
    private val dao = Room.databaseBuilder(context.applicationContext, PilotDb::class.java, "pilot-history.db")
        .build().reports()
    val recent = dao.observe()

    suspend fun save(report: Report, reason: String = "") {
        val rounds = JSONArray()
        for (battle in report.battles) rounds.put(JSONObject().put("trophies", battle.trophies)
            .put("result", battle.result.name).put("time", battle.time))
        dao.upsert(SavedReport(report.id, report.source.name, report.configuration.fighter, report.configuration.mode.label,
            report.initial, report.current, report.configuration.target, report.started,
            System.currentTimeMillis(), reason, rounds.toString()))
    }

    companion object {
        @Volatile private var instance: History? = null
        fun get(context: Context): History = instance ?: synchronized(this) {
            instance ?: History(context).also { instance = it }
        }
    }
}

class Catalog(private val context: Context) {
    private val file get() = android.util.AtomicFile(context.filesDir.resolve("fighter-catalog.txt"))

    suspend fun names(): List<String> = withContext(Dispatchers.IO) {
        val lines = runCatching { file.readFully().decodeToString().lineSequence().toList() }.getOrNull()
            ?: context.assets.open("fighters.txt").bufferedReader().use { it.readLines() }
        lines.filter { it.isNotBlank() }.map { Profiles.find(it)?.name ?: it }
            .distinct().sortedWith(String.CASE_INSENSITIVE_ORDER)
    }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        val connection = URL("https://api.brawlapi.com/v1/brawlers").openConnection() as HttpsURLConnection
        connection.connectTimeout = 7000
        connection.readTimeout = 10000
        connection.setRequestProperty("Accept", "application/json")
        try {
            check(connection.responseCode == 200) { "Каталог недоступен" }
            val bytes = connection.inputStream.use { stream ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (output.size() <= 2_000_000) {
                    val read = stream.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                }
                output.toByteArray()
            }
            check(bytes.size <= 2_000_000) { "Ответ слишком большой" }
            val list = JSONObject(bytes.decodeToString()).getJSONArray("list")
            val names = (0 until list.length()).mapNotNull { index ->
                list.getJSONObject(index).optString("name").trim().takeIf { it.length in 1..64 && '\n' !in it }
            }.distinct()
            check(names.size >= 30) { "Неполный каталог" }
            val output = file.startWrite()
            try {
                output.write(names.joinToString("\n").encodeToByteArray())
                file.finishWrite(output)
            } catch (error: Exception) {
                file.failWrite(output)
                throw error
            }
        } finally {
            connection.disconnect()
        }
        names()
    }
}
