package pilot.screen

import android.graphics.Bitmap
import pilot.domain.*
import pilot.engine.Pilot
import pilot.engine.Session
import pilot.vision.*
import kotlin.math.abs

internal class LiveSession(
    private val configuration: Configuration,
    private val calibration: Calibration
) {
    var session: Session? = null
        private set
    var message = "Открой лобби выбранного бойца"
        private set
    var done = false
        private set
    var paused = false
        private set
    var debug: World? = null
        private set
    var roundsSaved = 0
    private var expectedResult = Result.UNKNOWN
    private var visionMatches = 0
    private var unknownSince = 0L
    private var entered = System.currentTimeMillis()
    private val started = entered
    private var pendingTrophies: Int? = null
    private var lastRead = 0L
    private var lastAction = 0L
    private var lastAttack = 0L
    private var exited = false
    private var pilot = Pilot()
    val options get() = configuration.options
    val phase get() = when {
        done -> Phase.DONE
        paused -> Phase.PAUSED
        else -> session?.phase ?: Phase.HOME
    }

    fun stop(reason: String) {
        session?.stop(reason)
        message = reason
        done = true
    }

    fun pause(reason: String) {
        if (done) return
        session?.pause(reason)
        paused = true
        message = reason
    }

    fun resume() {
        if (done || !paused) return
        val now = System.currentTimeMillis()
        if (session?.resume(now) == false) {
            stop(session?.message ?: "Достигнут лимит времени")
            return
        }
        paused = false
        entered = now
        unknownSince = 0
        pendingTrophies = null
        visionMatches = 0
        message = "Проверяю экран"
    }

    fun tick(now: Long) {
        if (session != null && session?.timeCheck(now) == false) stop(session!!.message)
        else if (now - started >= options.seconds * 1000L) stop("Достигнут лимит времени")
    }

    fun lost(reason: String, now: Long, tolerance: Long = 3000) {
        if (done || paused) return
        if (unknownSince == 0L) unknownSince = now
        message = reason
        if (now - unknownSince >= tolerance) {
            if (options.autoPause) pause(reason) else stop(reason)
        }
    }

    suspend fun process(frame: Bitmap, vision: FrameVision, now: Long, dt: Float) {
        if (done || paused) return
        debug = null
        if (!calibration.comparable(frame)) {
            lost("Изменился размер или ориентация кадра", now)
            return
        }
        val view = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            vision.inspect(frame, calibration, options.confidence, dt)
        }
        if (done || paused) return
        if (options.debugBoxes) debug = view.world
        val active = session
        if (active == null) {
            if (!view.lobby || !view.play) {
                pendingTrophies = null
                lost("Открой калиброванное лобби с выбранным бойцом и режимом", now, 18_000)
                return
            }
            unknownSince = 0
            message = "Сверяю начальные кубки"
            val first = readStable(frame, vision, now)
            if (done || paused) return
            if (first == null) {
                if (now - entered > 12_000) pause("Кубки в лобби не распознаны")
                return
            }
            session = Session(configuration, Source.GAME, first, started)
            if (session?.phase == Phase.DONE) {
                stop("Цель уже достигнута")
                return
            }
            advance(Phase.BRAWLER_SELECTION, now)
            advance(Phase.MODE_SELECTION, now)
            return
        }
        val outcome = view.result
        when (active.phase) {
            Phase.MODE_SELECTION, Phase.NEXT_MATCH -> {
                if (view.lobby && view.play && !view.hud) {
                    unknownSince = 0
                    message = "Нажимаю «Играть»"
                    if (ready(now) && tap(Mark.PLAY)) advance(Phase.MATCHMAKING, now)
                } else lost("Лобби или кнопка запуска не подтверждены", now)
            }
            Phase.MATCHMAKING -> {
                val changed = !view.lobby || !view.play
                if (changed) {
                    visionMatches++
                    if (visionMatches >= 2) advance(Phase.LOADING, now)
                } else {
                    visionMatches = 0
                    if (now - entered > 9000) pause("Очередь не открылась")
                }
            }
            Phase.LOADING -> {
                if (view.hud && view.world?.self != null) {
                    visionMatches++
                    if (visionMatches >= 2) {
                        pilot = Pilot()
                        lastAttack = 0
                        advance(Phase.IN_MATCH, now)
                    }
                } else {
                    visionMatches = 0
                    if (now - entered > 75_000) pause("Бой не подтверждён за 75 секунд")
                }
            }
            Phase.IN_MATCH -> {
                when {
                    outcome != null && view.exit && !view.lobby -> {
                        visionMatches++
                        if (visionMatches >= 2) {
                            expectedResult = outcome
                            exited = false
                            advance(Phase.RESULTS, now)
                        }
                    }
                    view.hud && !view.exit && !view.lobby -> {
                        visionMatches = 0
                        val world = view.world
                        if (world == null || world.confidence < options.confidence) {
                            lost("Боец не распознан с нужной уверенностью", now, 14_000)
                        } else {
                            unknownSince = 0
                            val decision = pilot.decide(world, configuration.profile, configuration.mode, options, dt)
                            message = decision.reason
                            control(world, decision, now)
                        }
                    }
                    else -> {
                        visionMatches = 0
                        lost("Экран боя изменился", now, 14_000)
                    }
                }
            }
            Phase.RESULTS -> {
                if (view.exit && view.result == expectedResult && !view.lobby && ready(now)) {
                    if (tap(Mark.EXIT)) {
                        exited = true
                        advance(Phase.TROPHY_CHECK, now)
                    }
                } else if (now - entered > 9000) pause("Кнопка выхода не подтверждена")
            }
            Phase.TROPHY_CHECK -> {
                if (exited && view.lobby && !view.hud) {
                    message = "Проверяю кубки после матча"
                    val value = readStable(frame, vision, now)
                    if (done || paused) return
                    if (value != null && active.record(value, expectedResult, now)) {
                        if (active.phase == Phase.DONE) stop(active.message)
                        else {
                            message = "Кубки подтверждены"
                            entered = now
                        }
                    } else if (now - entered > 12_000) pause("Кубки после матча не удалось подтвердить")
                } else {
                    pendingTrophies = null
                    if (now - entered > 12_000) pause("Возврат в лобби не подтверждён")
                }
            }
            else -> Unit
        }
    }

    private fun advance(next: Phase, now: Long) {
        if (session?.step(next) != true) return
        entered = now
        unknownSince = 0
        pendingTrophies = null
        visionMatches = 0
        message = when (next) {
            Phase.MATCHMAKING -> "Матч запрошен"
            Phase.LOADING -> "Ожидаю начало матча"
            Phase.IN_MATCH -> "Бой подтверждён"
            Phase.RESULTS -> "Результат распознан"
            Phase.TROPHY_CHECK -> "Ожидаю лобби"
            else -> "Боец и режим подтверждены"
        }
    }

    private suspend fun readStable(frame: Bitmap, vision: FrameVision, now: Long): Int? {
        if (now - lastRead < 475L) return null
        lastRead = now
        val reference = calibration.marks[Mark.TROPHIES] ?: return null
        val value = vision.trophies(frame, reference)
        val verified = value?.takeIf { it == pendingTrophies }
        pendingTrophies = value
        return verified
    }

    private fun tap(mark: Mark): Boolean {
        val center = calibration.marks[mark]?.area?.center ?: return false
        return PilotGestures.instance?.send(listOf(PilotGestures.Touch(center))) == true
    }

    private fun ready(now: Long): Boolean {
        if (now - lastAction < 700L) return false
        lastAction = now
        return true
    }

    private fun control(world: World, decision: Decision, now: Long) {
        val self = world.self ?: return
        val gestures = PilotGestures.instance ?: return
        val inputs = mutableListOf<PilotGestures.Touch>()
        val movement = calibration.marks[Mark.MOVE]!!.area
        if (decision.movement != Vec.ZERO) {
            inputs += swipe(movement, decision.movement, 175)
        }
        val aim = decision.aim
        val attack = if (decision.superAttack) calibration.marks[Mark.SUPER]?.area else calibration.marks[Mark.ATTACK]?.area
        val shot = if (aim != null && attack != null &&
            now - lastAttack >= (configuration.profile.cooldown * 1000).toLong()) {
            swipe(attack, (aim - self.point).direction(), 120)
        } else null
        if (shot != null) inputs += shot
        if (gestures.send(inputs) && shot != null) lastAttack = now
    }

    private fun swipe(area: Area, vector: Vec, time: Long): PilotGestures.Touch {
        val width = abs(area.right - area.left).coerceIn(.045f, .16f)
        val height = abs(area.bottom - area.top).coerceIn(.075f, .25f)
        val offset = Vec(vector.x * width * .69f, vector.y * height * .69f)
        return PilotGestures.Touch(area.center, (area.center + offset).clamp(), time)
    }
}
