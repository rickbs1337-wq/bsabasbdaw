package pilot.screen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import pilot.domain.Vec

class PilotGestures : AccessibilityService() {
    private var busy = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun gameVisible(): Boolean {
        val root = rootInActiveWindow ?: return false
        val visible = root.packageName?.toString() == GAME_PACKAGE
        @Suppress("DEPRECATION")
        root.recycle()
        return visible
    }

    fun send(touches: List<Touch>): Boolean {
        if (busy || touches.isEmpty() || !gameVisible()) return false
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(metrics)
        if (metrics.widthPixels <= metrics.heightPixels) return false
        val builder = GestureDescription.Builder()
        for (touch in touches) {
            val start = touch.from.clamp()
            val end = touch.to.clamp()
            val path = Path().apply {
                moveTo(start.x * metrics.widthPixels, start.y * metrics.heightPixels)
                if (start != end) lineTo(end.x * metrics.widthPixels, end.y * metrics.heightPixels)
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, touch.millis))
        }
        busy = true
        val sent = dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) { busy = false }
            override fun onCancelled(gestureDescription: GestureDescription) { busy = false }
        }, null)
        if (!sent) busy = false
        return sent
    }

    data class Touch(val from: Vec, val to: Vec = from, val millis: Long = 70L)

    companion object {
        const val GAME_PACKAGE = "com.supercell.brawlstars"
        @Volatile internal var instance: PilotGestures? = null
        fun enabled() = instance != null
    }
}
