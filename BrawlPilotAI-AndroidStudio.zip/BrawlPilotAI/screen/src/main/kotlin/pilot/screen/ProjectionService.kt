package pilot.screen

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import pilot.data.History
import pilot.domain.Phase
import pilot.vision.CalibrationStore
import pilot.vision.FrameVision
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.roundToInt

class ProjectionService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var notifications: NotificationManager
    private lateinit var windows: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var dimensions = Size(0, 0, 0)
    private var loop: Job? = null
    private var active: LiveSession? = null
    private var freeze = false
    private var freezeAfter = 0L
    private var overlay: LinearLayout? = null
    private var overlayText: TextView? = null
    private var compact = false
    private var notice: String? = null
    private var serial = 0
    private var lastLogged = ""

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { shutdown("Android завершил захват") }
    }

    override fun onCreate() {
        super.onCreate()
        windows = getSystemService(WindowManager::class.java)
        notifications = getSystemService(NotificationManager::class.java)
        notifications.createNotificationChannel(NotificationChannel(CHANNEL, "BrawlPilot · Захват экрана", NotificationManager.IMPORTANCE_LOW))
        notifications.createNotificationChannel(NotificationChannel(FINISH, "BrawlPilot · Результат", NotificationManager.IMPORTANCE_DEFAULT))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> start(intent)
            STOP -> shutdown("Остановлено вручную")
            PAUSE -> {
                val session = active
                if (session != null) {
                    if (session.paused) session.resume() else session.pause("Пауза")
                    publish()
                }
            }
            SNAPSHOT -> if (projection != null && active == null) {
                requestSnapshot()
                notice = "Открой нужный экран игры. Снимок появится в BrawlPilot"
                publish()
            }
            OVERLAY -> {
                if (overlay == null && projection != null) showOverlay() else hideOverlay()
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (projection != null) return
        startForeground(NOTIFICATION, notification("Запускаю захват"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA, Intent::class.java)
            else intent.getParcelableExtra(EXTRA)
        if (data == null) {
            shutdown("Разрешение на захват не получено")
            return
        }
        try {
            projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(Activity.RESULT_OK, data)
                ?: error("Разрешение истекло")
            projection!!.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
            resize()
            active = null
            notice = null
            lastLogged = ""
            LiveBus.mutable.value = LiveStatus(capturing = true, message = "Захват включён")
            if (Settings.canDrawOverlays(this)) showOverlay()
            loop = scope.launch { collectFrames() }
        } catch (error: Exception) {
            shutdown("Захват не запущен")
        }
    }

    private data class Size(val width: Int, val height: Int, val density: Int)

    @Suppress("DEPRECATION")
    private fun resize() {
        val metrics = DisplayMetrics()
        windows.defaultDisplay.getRealMetrics(metrics)
        val ratio = minOf(1f, 960f / max(metrics.widthPixels, metrics.heightPixels).coerceAtLeast(1))
        val size = Size((metrics.widthPixels * ratio).roundToInt(), (metrics.heightPixels * ratio).roundToInt(),
            metrics.densityDpi)
        if (dimensions == size) return
        val target = ImageReader.newInstance(size.width, size.height, PixelFormat.RGBA_8888, 3)
        try {
            val old = display
            if (old == null) {
                display = projection!!.createVirtualDisplay("BrawlPilot", size.width, size.height, size.density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, target.surface, null, null)
                    ?: error("Виртуальный дисплей не создан")
            } else {
                old.surface = null
                old.resize(size.width, size.height, size.density)
                old.surface = target.surface
            }
        } catch (error: Exception) {
            target.close()
            throw error
        }
        reader?.close()
        reader = target
        dimensions = size
    }

    private suspend fun collectFrames() {
        val vision = FrameVision()
        var previousFrame = 0L
        var previousNotice = ""
        var notificationTime = 0L
        var lastFrame = System.currentTimeMillis()
        try {
            while (currentCoroutineContext().isActive) {
                val requested = LiveBus.request
                LiveBus.request = null
                if (requested != null && active == null) {
                    val calibration = CalibrationStore(this).read()
                    if (calibration.missing.isEmpty() && calibration.fighter == requested.fighter &&
                        PilotGestures.enabled() && requested.mode == pilot.domain.Mode.SURVIVAL) {
                        active = LiveSession(requested, calibration)
                        notice = null
                        lastLogged = ""
                        freeze = false
                    } else notice = "Проверь калибровку, режим и разрешение на жесты"
                }
                val current = active
                val now = System.currentTimeMillis()
                current?.tick(now)
                if (current?.done == true) {
                    store(current, true)
                    publish()
                    if (current.session?.report?.let { it.current >= it.configuration.target } == true) {
                        notifications.notify(FINISHED, notification(current.message, true))
                    }
                    shutdown(current.message)
                    break
                }
                resize()
                val gameVisible = PilotGestures.instance?.gameVisible() == true
                if (current != null && !gameVisible) {
                    current.lost("Открой Brawl Stars или включи разрешение на жесты", now, 8000)
                } else if (current != null && !online()) {
                    current.lost("Соединение с интернетом потеряно", now, 5000)
                } else if (gameVisible && (freeze || current?.paused == false)) {
                    val frame = getBitmap()
                    if (frame != null) {
                        lastFrame = now
                        try {
                            val dt = if (previousFrame == 0L) .2f else ((now - previousFrame) / 1000f).coerceIn(.04f, .8f)
                            previousFrame = now
                            if (freeze && now >= freezeAfter) {
                                freeze = false
                                notice = "Кадр готов. Вернись в BrawlPilot"
                                LiveBus.image.value = frame.copy(Bitmap.Config.ARGB_8888, false)
                            }
                            if (current != null) {
                                try {
                                    current.process(frame, vision, now, dt)
                                } catch (cancel: CancellationException) {
                                    throw cancel
                                } catch (_: Exception) {
                                    current.lost("Ошибка распознавания кадра", now)
                                }
                            }
                        } finally {
                            frame.recycle()
                        }
                    } else if (current != null && now - lastFrame > 1500) {
                        current.lost("Android не передаёт кадры", now)
                    }
                }
                if (!gameVisible || current?.paused == true || current == null && !freeze) {
                    reader?.acquireLatestImage()?.close()
                }
                if (current != null) store(current)
                publish()
                val updated = LiveBus.status.value.message
                if (updated != previousNotice && now - notificationTime > 1200) {
                    notifications.notify(NOTIFICATION, notification(updated))
                    previousNotice = updated
                    notificationTime = now
                }
                delay(1000L / (current?.options?.fps ?: 4))
            }
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: Exception) {
            shutdown("Захват прерван из-за ошибки")
        } finally {
            vision.close()
        }
    }

    private fun online(): Boolean {
        val manager = getSystemService(ConnectivityManager::class.java)
        val network = manager.activeNetwork ?: return false
        return manager.getNetworkCapabilities(network)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }

    private suspend fun store(current: LiveSession, final: Boolean = false) {
        val report = current.session?.report ?: return
        if (final || report.battles.size != current.roundsSaved) {
            History.get(this).save(report, if (final) current.message else "")
            current.roundsSaved = report.battles.size
        }
    }

    private suspend fun getBitmap(): Bitmap? {
        val image = reader?.acquireLatestImage() ?: return null
        val plane = image.planes.first()
        val width = image.width
        val height = image.height
        val stride = plane.rowStride
        val buffer: ByteBuffer = plane.buffer
        val bytes = ByteArray(stride * (height - 1) + width * 4)
        try {
            if (plane.pixelStride != 4 || buffer.remaining() < bytes.size) return null
            buffer.get(bytes)
        } finally {
            image.close()
        }
        return withContext(Dispatchers.Default) {
            val pixels = IntArray(width * height)
            for (y in 0 until height) for (x in 0 until width) {
                val index = y * stride + x * 4
                pixels[y * width + x] = Color.rgb(bytes[index].toInt() and 255, bytes[index + 1].toInt() and 255,
                    bytes[index + 2].toInt() and 255)
            }
            Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
        }
    }

    private fun publish(capturing: Boolean = projection != null) {
        val current = active
        val old = LiveBus.mutable.value
        val report = current?.session?.report
        val message = current?.message ?: notice ?: if (capturing) "Захват включён" else old.message
        val phase = current?.phase ?: if (capturing) Phase.IDLE else old.phase
        var logs = old.logs
        val event = "${phase.name}  ·  $message"
        if (current?.options?.diagnostics == true && event != lastLogged) {
            lastLogged = event
            logs = (logs + "${++serial}. $event").takeLast(38)
        }
        LiveBus.mutable.value = LiveStatus(capturing, current != null && !current.done, phase,
            message, report?.current, report, logs, current?.debug)
        val overlayLabel = if (report == null) message
            else "${report.configuration.fighter}  ${report.current}/${report.configuration.target}\n$message"
        if (overlayText?.text != overlayLabel) overlayText?.text = overlayLabel
    }

    private fun shutdown(reason: String) {
        if (projection == null && loop == null) {
            notice = reason
            publish(false)
            stopSelf()
            return
        }
        active?.stop(reason)
        val report = active?.session?.report
        if (report != null) {
            val storedReason = active?.message ?: reason
            persistence.launch { runCatching { History.get(applicationContext).save(report, storedReason) } }
        }
        notice = reason
        loop?.cancel()
        loop = null
        display?.release()
        display = null
        reader?.close()
        reader = null
        val previous = projection
        projection = null
        previous?.unregisterCallback(projectionCallback)
        previous?.stop()
        hideOverlay()
        LiveBus.request = null
        publish(false)
        if (active != null) {
            val logs = LiveBus.status.value.logs
            persistence.launch { runCatching { LiveBus.saveDiagnostics(applicationContext, logs) } }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        shutdown("Приложение закрыто")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        if (projection != null) shutdown("Захват завершён")
        scope.cancel()
        super.onDestroy()
    }

    private fun notification(message: String, finished: Boolean = false): Notification {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        val builder = Notification.Builder(this, if (finished) FINISH else CHANNEL)
            .setSmallIcon(if (finished) android.R.drawable.star_on else android.R.drawable.ic_menu_camera)
            .setContentTitle("BrawlPilot AI")
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setOngoing(!finished)
            .setOnlyAlertOnce(true)
        if (intent != null) builder.setContentIntent(PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE))
        if (!finished) for ((key, label) in listOf(SNAPSHOT to "Снимок", PAUSE to "Пауза", STOP to "Стоп")) {
            val pending = PendingIntent.getService(this, key.hashCode(), Intent(this, ProjectionService::class.java).setAction(key),
                PendingIntent.FLAG_IMMUTABLE)
            builder.addAction(Notification.Action.Builder(null, label, pending).build())
        }
        return builder.build()
    }

    private fun showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(4), dp(9), dp(4))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xe9241e46.toInt(), 0xe6111427.toInt())).apply {
                cornerRadius = dp(17).toFloat()
                setStroke(dp(1), 0xff6d60b4.toInt())
            }
        }
        fun item(text: String, click: (() -> Unit)?): TextView = TextView(this).apply {
            this.text = text
            setTextColor(0xfff2ecff.toInt())
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), dp(10), dp(6), dp(10))
            if (click != null) setOnClickListener { click() }
            row.addView(this)
        }
        item(if (compact) "◆" else "‹") {
            compact = !compact
            hideOverlay()
            showOverlay()
            publish()
        }
        if (!compact) {
            overlayText = item(LiveBus.status.value.message, null).apply { maxWidth = dp(185); maxLines = 2 }
            item("Снимок") { if (active == null) requestSnapshot() }
            item("Пауза") {
                active?.let { if (it.paused) it.resume() else it.pause("Пауза") }
                publish()
            }
            item("Стоп") { shutdown("Остановлено вручную") }
        }
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(10)
        }
        try {
            windows.addView(row, params)
            overlay = row
        } catch (_: RuntimeException) { overlayText = null }
    }

    private fun requestSnapshot() {
        freeze = true
        freezeAfter = System.currentTimeMillis() + 350
    }

    private fun hideOverlay() {
        overlay?.let { runCatching { windows.removeView(it) } }
        overlay = null
        overlayText = null
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()

    companion object {
        private val persistence = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private const val CHANNEL = "projection"
        private const val FINISH = "goal"
        private const val NOTIFICATION = 41
        private const val FINISHED = 42
        private const val START = "start"
        private const val EXTRA = "permission"
        const val STOP = "stop"
        const val PAUSE = "pause"
        const val SNAPSHOT = "snapshot"
        const val OVERLAY = "overlay"

        fun consentIntent(context: Context): Intent {
            val manager = context.getSystemService(MediaProjectionManager::class.java)
            return if (Build.VERSION.SDK_INT >= 34) manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                else manager.createScreenCaptureIntent()
        }

        fun begin(context: Context, data: Intent) {
            ContextCompat.startForegroundService(context, Intent(context, ProjectionService::class.java)
                .setAction(START).putExtra(EXTRA, data))
        }

        fun command(context: Context, action: String) {
            if (LiveBus.status.value.capturing) context.startService(Intent(context, ProjectionService::class.java)
                .setAction(action))
        }
    }
}
