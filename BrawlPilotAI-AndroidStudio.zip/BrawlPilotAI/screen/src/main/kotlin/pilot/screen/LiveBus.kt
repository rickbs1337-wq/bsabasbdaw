package pilot.screen

import android.content.Context
import android.graphics.Bitmap
import android.util.AtomicFile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import pilot.domain.Configuration
import pilot.domain.Phase
import pilot.domain.Report
import pilot.domain.World

data class LiveStatus(
    val capturing: Boolean = false,
    val active: Boolean = false,
    val phase: Phase = Phase.IDLE,
    val message: String = "Захват выключен",
    val trophies: Int? = null,
    val report: Report? = null,
    val logs: List<String> = emptyList(),
    val debug: World? = null
)

object LiveBus {
    internal val mutable = MutableStateFlow(LiveStatus())
    internal val image = MutableStateFlow<Bitmap?>(null)
    val status = mutable.asStateFlow()
    val snapshot = image.asStateFlow()
    internal var request: Configuration? = null

    fun arm(configuration: Configuration): Boolean {
        if (!status.value.capturing || status.value.active || request != null) return false
        request = configuration
        return true
    }

    fun clearSnapshot() { image.value = null }

    fun restoreDiagnostics(context: Context) {
        if (mutable.value.capturing || mutable.value.logs.isNotEmpty()) return
        val recent = runCatching { diagnosticsFile(context).readFully().decodeToString().lines().takeLast(38) }
            .getOrDefault(emptyList()).filter { it.isNotBlank() }
        if (!mutable.value.capturing && mutable.value.logs.isEmpty()) {
            mutable.value = mutable.value.copy(logs = recent)
        }
    }

    internal fun saveDiagnostics(context: Context, logs: List<String>) {
        val file = diagnosticsFile(context)
        val output = file.startWrite()
        try {
            output.write(logs.joinToString("\n").encodeToByteArray())
            file.finishWrite(output)
        } catch (error: Exception) {
            file.failWrite(output)
            throw error
        }
    }

    private fun diagnosticsFile(context: Context) = AtomicFile(context.filesDir.resolve("last-live-diagnostics.txt"))
}
